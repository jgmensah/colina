import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ModeToggle } from "@/components/mode-toggle"

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-gradient-to-r from-purple-600 to-purple-800 text-white dark:from-purple-900 dark:to-purple-950">
        <div className="container flex h-16 items-center px-4 sm:px-6">
          <Link href="/" className="text-lg font-semibold">
            Colina
          </Link>
          <nav className="ml-auto flex gap-4 items-center">
            <Link href="/" className="text-sm font-medium hover:text-purple-200">
              Home
            </Link>
            <Link href="/dashboard" className="text-sm font-medium hover:text-purple-200">
              Dashboard
            </Link>
            <ModeToggle />
          </nav>
        </div>
      </header>

      <main className="flex-1 container py-12">
        <div className="flex items-center mb-8">
          <Link href="/">
            <Button variant="outline" className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-purple-700 dark:text-purple-300">About Colina</h1>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          <Card className="border-purple-200 shadow-md dark:border-purple-800">
            <CardHeader>
              <CardTitle className="text-purple-700 dark:text-purple-300">About the App</CardTitle>
              <CardDescription>Learn more about Colina</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Colina is a comprehensive financial management application designed to help users in Ghana take control
                of their finances. The app provides tools for budget tracking, expense management, and investment
                portfolio monitoring, all in Ghana Cedis (GHS).
              </p>
              <p>With Colina, you can:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Create and manage budgets for different expense categories</li>
                <li>Track your income and expenses</li>
                <li>Monitor your investment portfolio performance</li>
                <li>Generate reports and visualizations of your financial data</li>
                <li>Set financial goals and track your progress</li>
              </ul>
              <p>
                Colina is designed to be user-friendly and accessible on both mobile and desktop devices. The app can be
                installed as a Progressive Web App (PWA) for offline access and a native-like experience.
              </p>
            </CardContent>
          </Card>

          <Card className="border-purple-200 shadow-md dark:border-purple-800">
            <CardHeader>
              <CardTitle className="text-purple-700 dark:text-purple-300">About the Developer</CardTitle>
              <CardDescription>Meet the creator of Colina</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Colina was developed by <strong>Joshmen Carter</strong>, a passionate software developer dedicated to
                creating tools that help people manage their finances effectively.
              </p>
              <p>
                With a background in finance and technology, Joshmen recognized the need for a financial management
                application specifically designed for users in Ghana, with support for the local currency and financial
                products.
              </p>
              <p>
                Joshmen is committed to continuously improving Colina based on user feedback and adding new features to
                enhance the financial management experience.
              </p>
              <div className="mt-6 pt-6 border-t border-purple-200 dark:border-purple-800">
                <h3 className="font-semibold mb-2 text-purple-700 dark:text-purple-300">Contact the Developer</h3>
                <p>
                  For inquiries, feedback, or support, you can reach out to Joshmen through the
                  <Link
                    href="/support"
                    className="text-purple-600 hover:text-purple-800 dark:text-purple-400 dark:hover:text-purple-300 mx-1"
                  >
                    Support page
                  </Link>
                  or visit the GitHub repository for the project.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="border-t border-purple-200 py-6 md:py-0 bg-white dark:bg-purple-950 dark:border-purple-800">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-purple-600 dark:text-purple-300">© 2024 Colina. All rights reserved.</p>
          <div className="flex gap-4">
            <Link
              href="/about"
              className="text-sm text-purple-600 hover:text-purple-800 dark:text-purple-300 dark:hover:text-purple-100"
            >
              About
            </Link>
            <Link
              href="/support"
              className="text-sm text-purple-600 hover:text-purple-800 dark:text-purple-300 dark:hover:text-purple-100"
            >
              Support
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
