import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ModeToggle } from "@/components/mode-toggle"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-gradient-to-r from-purple-600 to-purple-800 text-white dark:from-purple-900 dark:to-purple-950">
        <div className="container flex h-16 items-center px-4 sm:px-6">
          <h1 className="text-lg font-semibold">Colina</h1>
          <nav className="ml-auto flex gap-4 items-center">
            <Link href="/signin" className="text-sm font-medium hover:text-purple-200">
              Sign In
            </Link>
            <Link href="/signup" className="text-sm font-medium hover:text-purple-200">
              Sign Up
            </Link>
            <ModeToggle />
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-purple-600 to-purple-800 text-white dark:from-purple-900 dark:to-purple-950">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Take Control of Your Finances
                </h1>
                <p className="mx-auto max-w-[700px] text-purple-100 md:text-xl">
                  Track your spending, manage your budget, and reach your financial goals with Colina - your personal
                  financial assistant.
                </p>
              </div>
              <div className="space-x-4">
                <Link href="/signup">
                  <Button className="bg-white text-purple-700 hover:bg-purple-100 dark:bg-purple-300 dark:text-purple-900">
                    Get Started
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-purple-50 dark:bg-purple-900/20">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-3 lg:gap-12">
              <Card className="glass-card border-purple-200 shadow-lg dark:border-purple-800">
                <CardHeader>
                  <CardTitle className="text-purple-700 dark:text-purple-300">Track Budgets</CardTitle>
                  <CardDescription>Set up budget categories and allocate funds</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Create custom budget categories for different expenses like groceries, rent, entertainment, and
                    more. Allocate monthly funds in Ghana Cedis to each category to stay on track.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/signup">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-purple-300 text-purple-700 hover:bg-purple-100 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-900/50"
                    >
                      Start Budgeting
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
              <Card className="glass-card border-purple-200 shadow-lg dark:border-purple-800">
                <CardHeader>
                  <CardTitle className="text-purple-700 dark:text-purple-300">Manage Transactions</CardTitle>
                  <CardDescription>Record your income and expenses</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Easily log your transactions and assign them to specific budget categories. Keep track of where your
                    money is going with detailed transaction history in Ghana Cedis.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/signup">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-purple-300 text-purple-700 hover:bg-purple-100 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-900/50"
                    >
                      Track Expenses
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
              <Card className="glass-card border-purple-200 shadow-lg dark:border-purple-800">
                <CardHeader>
                  <CardTitle className="text-purple-700 dark:text-purple-300">Grow Investments</CardTitle>
                  <CardDescription>Track your investment portfolio</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Monitor your investment portfolio performance, track returns, and analyze asset allocation. Make
                    informed decisions to grow your wealth over time.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/signup">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-purple-300 text-purple-700 hover:bg-purple-100 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-900/50"
                    >
                      Manage Investments
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t border-purple-200 py-6 md:py-0 bg-white dark:bg-purple-950 dark:border-purple-800">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-purple-600 dark:text-purple-300">© 2025 Colina. All rights reserved.</p>
          <div className="flex gap-4">
            <Link
              href="/about"
              className="text-sm text-purple-600 hover:text-purple-800 dark:text-purple-300 dark:hover:text-purple-100"
            >
              About
            </Link>
            <Link
              href="/support"
              className="text-sm text-purple-600 hover:text-purple-800 dark:text-purple-300 dark:hover:text-purple-100"
            >
              Support
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
