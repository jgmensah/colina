"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ArrowLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { getInvestments, updateInvestment } from "@/lib/local-storage"

export default function EditInvestmentPage() {
  const router = useRouter()
  const params = useParams()
  const { user } = useAuth()
  const { toast } = useToast()
  const investmentId = params.id as string

  const [formData, setFormData] = useState({
    name: "",
    type: "",
    initialInvestment: "",
    currentValue: "",
    targetAmount: "",
    notes: "",
  })
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (!user) return

    const investments = getInvestments()
    const investment = investments.find((i) => i.id === investmentId && i.userId === user.id)

    if (investment) {
      setFormData({
        name: investment.name,
        type: investment.type,
        initialInvestment: investment.initialInvestment.toString(),
        currentValue: investment.currentValue.toString(),
        targetAmount: investment.targetAmount.toString(),
        notes: investment.notes || "",
      })
    } else {
      toast({
        title: "Error",
        description: "Investment not found",
        variant: "destructive",
      })
      router.push("/dashboard/investments")
    }

    setIsLoading(false)
  }, [investmentId, user, router, toast])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to update an investment",
        variant: "destructive",
      })
      return
    }

    if (!formData.name || !formData.type || !formData.initialInvestment || !formData.targetAmount) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const initialInvestment = Number.parseFloat(formData.initialInvestment)
      const currentValue = Number.parseFloat(formData.currentValue)
      const targetAmount = Number.parseFloat(formData.targetAmount)

      if (isNaN(initialInvestment) || initialInvestment <= 0) {
        throw new Error("Initial investment must be a positive number")
      }

      if (isNaN(currentValue) || currentValue < 0) {
        throw new Error("Current value must be a non-negative number")
      }

      if (isNaN(targetAmount) || targetAmount <= 0) {
        throw new Error("Target amount must be a positive number")
      }

      const updatedInvestment = updateInvestment(investmentId, {
        name: formData.name,
        type: formData.type,
        initialInvestment: initialInvestment,
        currentValue: currentValue,
        targetAmount: targetAmount,
        notes: formData.notes || null,
      })

      if (updatedInvestment) {
        toast({
          title: "Success",
          description: "Investment updated successfully",
        })
        router.push(`/dashboard/investments/${investmentId}`)
      } else {
        throw new Error("Failed to update investment")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update investment",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const investmentTypes = [
    "Treasury Bills",
    "Fixed Deposit",
    "Mutual Fund",
    "Stocks",
    "Bonds",
    "Real Estate",
    "Cryptocurrency",
    "Retirement Fund",
    "Education Fund",
    "Other",
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-t-purple-600 border-purple-200 rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-purple-700 dark:text-purple-300">Loading investment details...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Button variant="outline" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <h2 className="text-3xl font-bold tracking-tight text-purple-700 dark:text-purple-300">Edit Investment</h2>
      </div>

      <Card className="border-purple-200 shadow-md dark:border-purple-800">
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Investment Details</CardTitle>
            <CardDescription>Update your investment information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Investment Name</Label>
              <Input
                id="name"
                name="name"
                placeholder="e.g., Ghana Treasury Bills, Fixed Deposit"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Investment Type</Label>
              <Select value={formData.type} onValueChange={(value) => handleSelectChange("type", value)} required>
                <SelectTrigger id="type">
                  <SelectValue placeholder="Select investment type" />
                </SelectTrigger>
                <SelectContent>
                  {investmentTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="initialInvestment">Initial Investment</Label>
              <div className="relative">
                <span className="absolute left-3 top-2.5">GHS</span>
                <Input
                  id="initialInvestment"
                  name="initialInvestment"
                  type="number"
                  placeholder="0.00"
                  className="pl-12"
                  value={formData.initialInvestment}
                  onChange={handleChange}
                  min="0"
                  step="0.01"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="currentValue">Current Value</Label>
              <div className="relative">
                <span className="absolute left-3 top-2.5">GHS</span>
                <Input
                  id="currentValue"
                  name="currentValue"
                  type="number"
                  placeholder="0.00"
                  className="pl-12"
                  value={formData.currentValue}
                  onChange={handleChange}
                  min="0"
                  step="0.01"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="targetAmount">Target Amount</Label>
              <div className="relative">
                <span className="absolute left-3 top-2.5">GHS</span>
                <Input
                  id="targetAmount"
                  name="targetAmount"
                  type="number"
                  placeholder="0.00"
                  className="pl-12"
                  value={formData.targetAmount}
                  onChange={handleChange}
                  min="0"
                  step="0.01"
                  required
                />
              </div>
              <p className="text-xs text-muted-foreground">Set a target amount you aim to reach with this investment</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                name="notes"
                placeholder="Add any notes about this investment"
                value={formData.notes}
                onChange={handleChange}
                rows={3}
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" type="button" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Updating..." : "Update Investment"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
