import type React from "react"
interface DashboardShellProps {
  children: React.ReactNode
}

export function DashboardShell({ children }: DashboardShellProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b border-purple-200 bg-white dark:bg-purple-950 dark:border-purple-800">
        <div className="container flex h-16 items-center justify-between py-4">
          <h1 className="text-lg font-semibold text-purple-700 dark:text-purple-300">Budget Tracker</h1>
          <nav className="flex items-center space-x-4 lg:space-x-6">
            <a
              href="/dashboard"
              className="text-sm font-medium transition-colors hover:text-purple-700 dark:hover:text-purple-300"
            >
              Dashboard
            </a>
            <a
              href="/budgets"
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-purple-700 dark:hover:text-purple-300"
            >
              Budgets
            </a>
            <a
              href="/transactions"
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-purple-700 dark:hover:text-purple-300"
            >
              Transactions
            </a>
            <a
              href="/reports"
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-purple-700 dark:hover:text-purple-300"
            >
              Reports
            </a>
          </nav>
        </div>
      </header>
      <main className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex flex-col space-y-8">{children}</div>
      </main>
    </div>
  )
}
