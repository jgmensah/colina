// Types for our data models
export interface User {
  id: string
  fullName: string
  phoneNumber: string
  createdAt: string
  profilePicture?: string
}

export interface Budget {
  id: string
  userId: string
  name: string
  amount: number
  description: string | null
  type: "expense" | "income" // Added type field
  createdAt: string
}

export interface Transaction {
  id: string
  userId: string
  date: string
  description: string
  amount: number
  type: "income" | "expense"
  category: string
  budgetId: string | null
  createdAt: string
}

export interface Investment {
  id: string
  userId: string
  name: string
  type: string
  initialInvestment: number
  currentValue: number
  targetAmount: number
  notes: string | null
  dateAdded: string
  createdAt: string
  contributions: InvestmentContribution[]
}

export interface InvestmentContribution {
  id: string
  date: string
  amount: number
  notes: string | null
}

// Generate a random UUID
export function generateId(): string {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === "x" ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

// Initialize local storage with sample data if it doesn't exist
export function initializeLocalStorage() {
  // Check if data already exists
  if (typeof window !== "undefined" && !localStorage.getItem("colina_user")) {
    // Create a default user
    const defaultUser: User = {
      id: generateId(),
      fullName: "Demo User",
      phoneNumber: "0201234567",
      createdAt: new Date().toISOString(),
    }

    // Sample budgets
    const budgets: Budget[] = [
      {
        id: generateId(),
        userId: defaultUser.id,
        name: "Groceries",
        amount: 500,
        description: "Monthly grocery budget",
        type: "expense",
        createdAt: new Date().toISOString(),
      },
      {
        id: generateId(),
        userId: defaultUser.id,
        name: "Rent",
        amount: 1200,
        description: "Monthly rent payment",
        type: "expense",
        createdAt: new Date().toISOString(),
      },
      {
        id: generateId(),
        userId: defaultUser.id,
        name: "Utilities",
        amount: 200,
        description: "Electricity, water, and internet",
        type: "expense",
        createdAt: new Date().toISOString(),
      },
      {
        id: generateId(),
        userId: defaultUser.id,
        name: "Entertainment",
        amount: 300,
        description: "Movies, dining out, etc.",
        type: "expense",
        createdAt: new Date().toISOString(),
      },
      {
        id: generateId(),
        userId: defaultUser.id,
        name: "Salary",
        amount: 3000,
        description: "Monthly salary",
        type: "income",
        createdAt: new Date().toISOString(),
      },
    ]

    // Sample transactions
    const transactions: Transaction[] = [
      {
        id: generateId(),
        userId: defaultUser.id,
        date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        description: "Salary",
        amount: 3000,
        type: "income",
        category: "salary",
        budgetId: budgets[4].id,
        createdAt: new Date().toISOString(),
      },
      {
        id: generateId(),
        userId: defaultUser.id,
        date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        description: "Grocery shopping",
        amount: 120.5,
        type: "expense",
        category: "groceries",
        budgetId: budgets[0].id,
        createdAt: new Date().toISOString(),
      },
      {
        id: generateId(),
        userId: defaultUser.id,
        date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        description: "Rent payment",
        amount: 1200,
        type: "expense",
        category: "housing",
        budgetId: budgets[1].id,
        createdAt: new Date().toISOString(),
      },
      {
        id: generateId(),
        userId: defaultUser.id,
        date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        description: "Electric bill",
        amount: 85.75,
        type: "expense",
        category: "utilities",
        budgetId: budgets[2].id,
        createdAt: new Date().toISOString(),
      },
      {
        id: generateId(),
        userId: defaultUser.id,
        date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        description: "Movie tickets",
        amount: 30,
        type: "expense",
        category: "entertainment",
        budgetId: budgets[3].id,
        createdAt: new Date().toISOString(),
      },
    ]

    // Sample investments with contributions
    const investments: Investment[] = [
      {
        id: generateId(),
        userId: defaultUser.id,
        name: "Ghana Treasury Bills",
        type: "Treasury Bills",
        initialInvestment: 5000,
        currentValue: 5250,
        targetAmount: 10000,
        notes: "91-day T-bill",
        dateAdded: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString(),
        contributions: [
          {
            id: generateId(),
            date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
            amount: 5000,
            notes: "Initial investment",
          },
          {
            id: generateId(),
            date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
            amount: 250,
            notes: "Additional contribution",
          },
        ],
      },
      {
        id: generateId(),
        userId: defaultUser.id,
        name: "Fixed Deposit",
        type: "Fixed Deposit",
        initialInvestment: 10000,
        currentValue: 10600,
        targetAmount: 20000,
        notes: "6-month term",
        dateAdded: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString(),
        contributions: [
          {
            id: generateId(),
            date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(),
            amount: 10000,
            notes: "Initial investment",
          },
          {
            id: generateId(),
            date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
            amount: 600,
            notes: "Interest earned",
          },
        ],
      },
    ]

    // Save to local storage
    localStorage.setItem("colina_user", JSON.stringify(defaultUser))
    localStorage.setItem("colina_budgets", JSON.stringify(budgets))
    localStorage.setItem("colina_transactions", JSON.stringify(transactions))
    localStorage.setItem("colina_investments", JSON.stringify(investments))
  }
}

// Data access functions
export function getUser(): User | null {
  if (typeof window === "undefined") return null
  const userData = localStorage.getItem("colina_user")
  return userData ? JSON.parse(userData) : null
}

export function setUser(user: User) {
  if (typeof window === "undefined") return
  localStorage.setItem("colina_user", JSON.stringify(user))
}

export function getBudgets(): Budget[] {
  if (typeof window === "undefined") return []
  const budgetsData = localStorage.getItem("colina_budgets")
  return budgetsData ? JSON.parse(budgetsData) : []
}

export function addBudget(budget: Omit<Budget, "id" | "createdAt">) {
  if (typeof window === "undefined") return null
  const budgets = getBudgets()
  const newBudget: Budget = {
    ...budget,
    id: generateId(),
    createdAt: new Date().toISOString(),
  }
  budgets.push(newBudget)
  localStorage.setItem("colina_budgets", JSON.stringify(budgets))
  return newBudget
}

export function updateBudget(id: string, updates: Partial<Budget>) {
  if (typeof window === "undefined") return null
  const budgets = getBudgets()
  const index = budgets.findIndex((b) => b.id === id)
  if (index !== -1) {
    budgets[index] = { ...budgets[index], ...updates }
    localStorage.setItem("colina_budgets", JSON.stringify(budgets))
    return budgets[index]
  }
  return null
}

export function deleteBudget(id: string) {
  if (typeof window === "undefined") return
  const budgets = getBudgets()
  const filteredBudgets = budgets.filter((b) => b.id !== id)
  localStorage.setItem("colina_budgets", JSON.stringify(filteredBudgets))
}

export function getTransactions(): Transaction[] {
  if (typeof window === "undefined") return []
  const transactionsData = localStorage.getItem("colina_transactions")
  return transactionsData ? JSON.parse(transactionsData) : []
}

export function addTransaction(transaction: Omit<Transaction, "id" | "createdAt">) {
  if (typeof window === "undefined") return null
  const transactions = getTransactions()
  const newTransaction: Transaction = {
    ...transaction,
    id: generateId(),
    createdAt: new Date().toISOString(),
  }
  transactions.push(newTransaction)
  localStorage.setItem("colina_transactions", JSON.stringify(transactions))
  return newTransaction
}

export function updateTransaction(id: string, updates: Partial<Transaction>) {
  if (typeof window === "undefined") return null
  const transactions = getTransactions()
  const index = transactions.findIndex((t) => t.id === id)
  if (index !== -1) {
    transactions[index] = { ...transactions[index], ...updates }
    localStorage.setItem("colina_transactions", JSON.stringify(transactions))
    return transactions[index]
  }
  return null
}

export function deleteTransaction(id: string) {
  if (typeof window === "undefined") return
  const transactions = getTransactions()
  const filteredTransactions = transactions.filter((t) => t.id !== id)
  localStorage.setItem("colina_transactions", JSON.stringify(filteredTransactions))
}

export function getInvestments(): Investment[] {
  if (typeof window === "undefined") return []
  const investmentsData = localStorage.getItem("colina_investments")
  return investmentsData ? JSON.parse(investmentsData) : []
}

export function addInvestment(investment: Omit<Investment, "id" | "createdAt" | "contributions">) {
  if (typeof window === "undefined") return null
  const investments = getInvestments()

  // Create initial contribution
  const initialContribution: InvestmentContribution = {
    id: generateId(),
    date: investment.dateAdded,
    amount: investment.initialInvestment,
    notes: "Initial investment",
  }

  const newInvestment: Investment = {
    ...investment,
    id: generateId(),
    createdAt: new Date().toISOString(),
    contributions: [initialContribution],
  }

  investments.push(newInvestment)
  localStorage.setItem("colina_investments", JSON.stringify(investments))
  return newInvestment
}

export function updateInvestment(id: string, updates: Partial<Investment>) {
  if (typeof window === "undefined") return null
  const investments = getInvestments()
  const index = investments.findIndex((i) => i.id === id)
  if (index !== -1) {
    investments[index] = { ...investments[index], ...updates }
    localStorage.setItem("colina_investments", JSON.stringify(investments))
    return investments[index]
  }
  return null
}

export function deleteInvestment(id: string) {
  if (typeof window === "undefined") return
  const investments = getInvestments()
  const filteredInvestments = investments.filter((i) => i.id !== id)
  localStorage.setItem("colina_investments", JSON.stringify(filteredInvestments))
}

export function addInvestmentContribution(investmentId: string, contribution: Omit<InvestmentContribution, "id">) {
  if (typeof window === "undefined") return null
  const investments = getInvestments()
  const index = investments.findIndex((i) => i.id === investmentId)

  if (index !== -1) {
    const newContribution: InvestmentContribution = {
      ...contribution,
      id: generateId(),
    }

    // Add contribution to the investment
    investments[index].contributions.push(newContribution)

    // Update current value
    investments[index].currentValue += contribution.amount

    localStorage.setItem("colina_investments", JSON.stringify(investments))
    return investments[index]
  }

  return null
}

export function deleteInvestmentContribution(investmentId: string, contributionId: string) {
  if (typeof window === "undefined") return null
  const investments = getInvestments()
  const investmentIndex = investments.findIndex((i) => i.id === investmentId)

  if (investmentIndex !== -1) {
    const investment = investments[investmentIndex]
    const contributionIndex = investment.contributions.findIndex((c) => c.id === contributionId)

    if (contributionIndex !== -1) {
      const contribution = investment.contributions[contributionIndex]

      // Remove contribution amount from current value
      investment.currentValue -= contribution.amount

      // Remove contribution
      investment.contributions = investment.contributions.filter((c) => c.id !== contributionId)

      localStorage.setItem("colina_investments", JSON.stringify(investments))
      return investment
    }
  }

  return null
}

// Clear all data (for logout)
export function clearAllData() {
  if (typeof window === "undefined") return
  localStorage.removeItem("colina_user")
  localStorage.removeItem("colina_budgets")
  localStorage.removeItem("colina_transactions")
  localStorage.removeItem("colina_investments")
}
