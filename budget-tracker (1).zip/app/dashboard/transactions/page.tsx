"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowDownLeft, ArrowUpRight, Filter, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/components/auth-provider"
import { formatCurrency } from "@/lib/utils"
import { getTransactions, getBudgets, type Transaction, type Budget } from "@/lib/local-storage"
import { TransactionList } from "@/components/transaction-list"

export default function TransactionsPage() {
  const { user } = useAuth()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    const fetchData = () => {
      setLoading(true)
      const transactionData = getTransactions().filter((t) => t.userId === user.id)
      const budgetData = getBudgets().filter((b) => b.userId === user.id)

      setTransactions(transactionData)
      setBudgets(budgetData)
      setLoading(false)
    }

    fetchData()
  }, [user])

  const filteredTransactions = transactions.filter((transaction) => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = filterType === "all" || transaction.type === filterType
    return matchesSearch && matchesType
  })

  if (loading) {
    return <div className="flex justify-center items-center h-[60vh]">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold tracking-tight text-purple-700 dark:text-purple-300">Transactions</h2>
        <Link href="/dashboard/transactions/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add Transaction
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Transactions</CardTitle>
          <CardDescription>A list of all your transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-x-4 md:space-y-0">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search transactions..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Transactions</SelectItem>
                  <SelectItem value="income">Income Only</SelectItem>
                  <SelectItem value="expense">Expenses Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="mt-6 space-y-1">
            <div className="flex justify-between text-sm font-medium text-muted-foreground">
              <span>Summary</span>
              <span>Amount</span>
            </div>
            <div className="flex items-center justify-between rounded-md bg-purple-50 px-4 py-2 dark:bg-purple-900/20">
              <div className="flex items-center space-x-2">
                <ArrowUpRight className="h-4 w-4 text-purple-600" />
                <span>Total Income</span>
              </div>
              <span className="font-medium text-purple-600">
                +
                {formatCurrency(
                  filteredTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0),
                )}
              </span>
            </div>
            <div className="flex items-center justify-between rounded-md bg-muted px-4 py-2">
              <div className="flex items-center space-x-2">
                <ArrowDownLeft className="h-4 w-4 text-red-500" />
                <span>Total Expenses</span>
              </div>
              <span className="font-medium text-red-500">
                -
                {formatCurrency(
                  filteredTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0),
                )}
              </span>
            </div>
          </div>

          <div className="mt-6">
            <TransactionList transactions={filteredTransactions} budgets={budgets} />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
