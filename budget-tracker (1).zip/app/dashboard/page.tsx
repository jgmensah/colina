"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { ArrowUpRight, DollarSign, LineChart, Plus, Wallet } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/components/auth-provider"
import { formatCurrency } from "@/lib/utils"
import {
  type Budget,
  type Transaction,
  type Investment,
  getBudgets,
  getTransactions,
  getInvestments,
} from "@/lib/local-storage"
import { RecentTransactions } from "@/components/recent-transactions"
import { BudgetOverview } from "@/components/budget-overview"

export default function DashboardPage() {
  const { user } = useAuth()
  const [mounted, setMounted] = useState(false)
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [investments, setInvestments] = useState<Investment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setMounted(true)

    const fetchData = () => {
      if (!user) return

      setLoading(true)

      // Get data from local storage
      const budgetData = getBudgets().filter((b) => b.userId === user.id)
      const transactionData = getTransactions().filter((t) => t.userId === user.id)
      const investmentData = getInvestments().filter((i) => i.userId === user.id)

      setBudgets(budgetData)
      setTransactions(transactionData)
      setInvestments(investmentData)
      setLoading(false)
    }

    fetchData()
  }, [user])

  if (!mounted) {
    return null
  }

  const totalBudget = budgets.reduce((sum, budget) => sum + budget.amount, 0)
  const totalSpent = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)
  const totalIncome = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
  const balance = totalIncome - totalSpent

  const totalInvestmentValue = investments.reduce((sum, inv) => sum + inv.currentValue, 0)
  const totalInvestmentCost = investments.reduce((sum, inv) => sum + inv.initialInvestment, 0)
  const investmentGain = totalInvestmentValue - totalInvestmentCost
  const investmentGainPercentage = totalInvestmentCost > 0 ? (investmentGain / totalInvestmentCost) * 100 : 0

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold tracking-tight text-purple-700 dark:text-purple-300">Dashboard</h2>
        <div className="flex gap-2">
          <Link href="/dashboard/transactions/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Transaction
            </Button>
          </Link>
          <Link href="/dashboard/budgets/new">
            <Button variant="outline">
              <Plus className="mr-2 h-4 w-4" />
              New Budget
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-purple-200 shadow-md dark:border-purple-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(balance)}</div>
            <p className="text-xs text-muted-foreground">
              {balance >= 0 ? "+" : "-"}
              {formatCurrency(Math.abs(balance * 0.1))} from last month
            </p>
          </CardContent>
        </Card>
        <Card className="border-purple-200 shadow-md dark:border-purple-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Income</CardTitle>
            <ArrowUpRight className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalIncome)}</div>
            <p className="text-xs text-muted-foreground">+{formatCurrency(120)} from last month</p>
          </CardContent>
        </Card>
        <Card className="border-purple-200 shadow-md dark:border-purple-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
            <Wallet className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalSpent)}</div>
            <p className="text-xs text-muted-foreground">+{formatCurrency(25)} from last month</p>
          </CardContent>
        </Card>
        <Card className="border-purple-200 shadow-md dark:border-purple-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Investments</CardTitle>
            <LineChart className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalInvestmentValue)}</div>
            <p className="text-xs text-muted-foreground">
              {investmentGain >= 0 ? "+" : ""}
              {formatCurrency(investmentGain)} ({investmentGainPercentage.toFixed(1)}%)
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="bg-purple-100 dark:bg-purple-900/50">
          <TabsTrigger value="overview" className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800">
            Overview
          </TabsTrigger>
          <TabsTrigger
            value="transactions"
            className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800"
          >
            Recent Transactions
          </TabsTrigger>
          <TabsTrigger value="budgets" className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800">
            Budget Status
          </TabsTrigger>
          <TabsTrigger
            value="investments"
            className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800"
          >
            Investments
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4 border-purple-200 shadow-md dark:border-purple-800">
              <CardHeader>
                <CardTitle className="text-purple-700 dark:text-purple-300">Spending Overview</CardTitle>
              </CardHeader>
              <CardContent>
                {budgets.length > 0 ? (
                  <BudgetOverview budgets={budgets} transactions={transactions} />
                ) : (
                  <div className="flex items-center justify-center h-[350px] text-muted-foreground">
                    No budget data available
                  </div>
                )}
              </CardContent>
            </Card>
            <Card className="col-span-3 border-purple-200 shadow-md dark:border-purple-800">
              <CardHeader>
                <CardTitle className="text-purple-700 dark:text-purple-300">Recent Transactions</CardTitle>
                <CardDescription>Your most recent transactions across all accounts</CardDescription>
              </CardHeader>
              <CardContent>
                <RecentTransactions transactions={transactions} budgets={budgets} limit={5} />
              </CardContent>
              <CardFooter>
                <Link href="/dashboard/transactions">
                  <Button
                    variant="outline"
                    className="w-full border-purple-300 text-purple-700 hover:bg-purple-100 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-900/50"
                  >
                    View All Transactions
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Transactions</CardTitle>
              <CardDescription>A list of all your recent transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <RecentTransactions transactions={transactions} budgets={budgets} limit={10} />
            </CardContent>
            <CardFooter>
              <Link href="/dashboard/transactions">
                <Button variant="outline">View All</Button>
              </Link>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="budgets" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Budget Status</CardTitle>
              <CardDescription>Your current budget allocation and spending</CardDescription>
            </CardHeader>
            <CardContent>
              {budgets.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-muted-foreground mb-4">You haven't created any budgets yet.</p>
                  <Link href="/dashboard/budgets/new">
                    <Button>Create Your First Budget</Button>
                  </Link>
                </div>
              ) : (
                budgets.map((budget) => {
                  const spent = transactions
                    .filter((t) => t.budgetId === budget.id && t.type === "expense")
                    .reduce((sum, t) => sum + t.amount, 0)
                  const percentage = (spent / budget.amount) * 100

                  return (
                    <div key={budget.id} className="mb-4">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">{budget.name}</span>
                        <span className="text-sm font-medium">
                          {formatCurrency(spent)} / {formatCurrency(budget.amount)}
                        </span>
                      </div>
                      <Progress
                        value={percentage}
                        className="h-2 bg-purple-100"
                        indicatorClassName={
                          percentage > 100 ? "bg-red-500" : percentage > 80 ? "bg-amber-500" : "bg-purple-600"
                        }
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        {percentage > 100
                          ? `Over budget by ${formatCurrency(spent - budget.amount)}`
                          : `${budget.amount - spent > 0 ? `${formatCurrency(budget.amount - spent)} remaining` : "Budget depleted"}`}
                      </p>
                    </div>
                  )
                })
              )}
            </CardContent>
            <CardFooter>
              <Link href="/dashboard/budgets">
                <Button variant="outline">Manage Budgets</Button>
              </Link>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="investments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Investment Portfolio</CardTitle>
              <CardDescription>Your investment assets and performance</CardDescription>
            </CardHeader>
            <CardContent>
              {investments.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-muted-foreground mb-4">You haven't added any investments yet.</p>
                  <Link href="/dashboard/investments/new">
                    <Button>Add Your First Investment</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {investments.map((investment) => {
                    const gain = investment.currentValue - investment.initialInvestment
                    const gainPercentage = (gain / investment.initialInvestment) * 100
                    const progressPercentage = (investment.currentValue / investment.targetAmount) * 100

                    return (
                      <div
                        key={investment.id}
                        className="p-4 border rounded-lg border-purple-200 dark:border-purple-800"
                      >
                        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                          <div>
                            <h4 className="font-medium">{investment.name}</h4>
                            <p className="text-sm text-muted-foreground">{investment.type}</p>
                          </div>
                          <div className="flex flex-col items-end">
                            <p className="font-medium">{formatCurrency(investment.currentValue)}</p>
                            <p className={`text-sm ${gain >= 0 ? "text-green-600" : "text-red-600"}`}>
                              {gain >= 0 ? "+" : ""}
                              {formatCurrency(gain)} ({gainPercentage.toFixed(1)}%)
                            </p>
                          </div>
                        </div>
                        <div className="mt-2">
                          <div className="flex justify-between mb-1 text-xs">
                            <span>Progress to Target</span>
                            <span>
                              {formatCurrency(investment.currentValue)} / {formatCurrency(investment.targetAmount)}
                            </span>
                          </div>
                          <Progress
                            value={progressPercentage}
                            className="h-2 bg-purple-100"
                            indicatorClassName="bg-purple-600"
                          />
                          <p className="text-xs text-right mt-1">{progressPercentage.toFixed(1)}%</p>
                        </div>
                      </div>
                    )
                  })}

                  <div className="mt-4 p-4 bg-purple-50 rounded-lg dark:bg-purple-900/20">
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">Total Investment:</span>
                      <span>{formatCurrency(totalInvestmentCost)}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">Current Value:</span>
                      <span>{formatCurrency(totalInvestmentValue)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Total Gain/Loss:</span>
                      <span className={investmentGain >= 0 ? "text-green-600" : "text-red-600"}>
                        {investmentGain >= 0 ? "+" : ""}
                        {formatCurrency(investmentGain)} ({investmentGainPercentage.toFixed(1)}%)
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Link href="/dashboard/investments">
                <Button variant="outline">Manage Investments</Button>
              </Link>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
