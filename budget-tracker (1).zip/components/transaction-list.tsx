import { ArrowDownLeft, ArrowUpRight } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/utils"
import type { Budget, Transaction } from "@/lib/local-storage"

interface TransactionListProps {
  transactions: Transaction[]
  budgets?: Budget[]
}

export function TransactionList({ transactions, budgets = [] }: TransactionListProps) {
  return (
    <div className="space-y-4">
      {transactions.length === 0 ? (
        <p className="text-center text-muted-foreground py-4">No transactions found</p>
      ) : (
        <div className="rounded-md border">
          <div className="grid grid-cols-6 border-b px-4 py-2 font-medium">
            <div>Date</div>
            <div className="col-span-2">Description</div>
            <div>Category</div>
            <div>Type</div>
            <div className="text-right">Amount</div>
          </div>
          <div className="divide-y">
            {transactions.map((transaction) => {
              const budget = transaction.budgetId ? budgets.find((b) => b.id === transaction.budgetId) : null

              return (
                <div key={transaction.id} className="grid grid-cols-6 px-4 py-3">
                  <div>{format(new Date(transaction.date), "MMM d, yyyy")}</div>
                  <div className="col-span-2">{transaction.description}</div>
                  <div>{budget?.name || transaction.category}</div>
                  <div className="flex items-center">
                    {transaction.type === "income" ? (
                      <>
                        <ArrowUpRight className="mr-1 h-4 w-4 text-green-500" />
                        <span>Income</span>
                      </>
                    ) : (
                      <>
                        <ArrowDownLeft className="mr-1 h-4 w-4 text-red-500" />
                        <span>Expense</span>
                      </>
                    )}
                  </div>
                  <div
                    className={cn(
                      "text-right font-medium",
                      transaction.type === "income" ? "text-green-500" : "text-red-500",
                    )}
                  >
                    {transaction.type === "income" ? "+" : "-"}
                    {formatCurrency(transaction.amount)}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
