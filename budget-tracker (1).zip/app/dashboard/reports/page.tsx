"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { CalendarIcon, Download } from "lucide-react"
import { format, subMonths } from "date-fns"
import { jsPDF } from "jspdf"
import "jspdf-autotable"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import { useAuth } from "@/components/auth-provider"
import {
  getBudgets,
  getTransactions,
  getInvestments,
  type Budget,
  type Transaction,
  type Investment,
} from "@/lib/local-storage"
import { useToast } from "@/components/ui/use-toast"

export default function ReportsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [investments, setInvestments] = useState<Investment[]>([])
  const [loading, setLoading] = useState(true)
  const [currency, setCurrency] = useState("GHS")

  const [dateRange, setDateRange] = useState<{
    from: Date
    to: Date
  }>({
    from: subMonths(new Date(), 1),
    to: new Date(),
  })

  const [reportType, setReportType] = useState("expense-category")

  // Function to format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency,
    }).format(amount)
  }

  useEffect(() => {
    if (!user) return

    const fetchData = () => {
      setLoading(true)
      const budgetData = getBudgets().filter((b) => b.userId === user.id)
      const transactionData = getTransactions().filter((t) => t.userId === user.id)
      const investmentData = getInvestments().filter((i) => i.userId === user.id)

      setBudgets(budgetData)
      setTransactions(transactionData)
      setInvestments(investmentData)
      setLoading(false)
    }

    fetchData()
  }, [user])

  // Filter transactions by date range
  const filteredTransactions = transactions.filter((transaction) => {
    const transactionDate = new Date(transaction.date)
    return transactionDate >= dateRange.from && transactionDate <= dateRange.to
  })

  // Calculate summary data
  const totalIncome = filteredTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
  const totalExpenses = filteredTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)
  const netSavings = totalIncome - totalExpenses
  const savingsRate = totalIncome > 0 ? (netSavings / totalIncome) * 100 : 0

  const totalInvestments = investments.reduce((sum, i) => sum + i.currentValue, 0)
  const totalInvestmentTargets = investments.reduce((sum, i) => sum + i.targetAmount, 0)
  const investmentProgress = totalInvestmentTargets > 0 ? (totalInvestments / totalInvestmentTargets) * 100 : 0

  // Group expenses by category
  const expensesByCategory = filteredTransactions
    .filter((t) => t.type === "expense")
    .reduce(
      (acc, transaction) => {
        const category = transaction.category
        if (!acc[category]) {
          acc[category] = 0
        }
        acc[category] += transaction.amount
        return acc
      },
      {} as Record<string, number>,
    )

  const expenseCategoryData = Object.entries(expensesByCategory)
    .map(([name, value]) => ({
      name,
      value,
      percentage: totalExpenses > 0 ? (value / totalExpenses) * 100 : 0,
    }))
    .sort((a, b) => b.value - a.value)

  // Group transactions by month for monthly comparison
  const monthlyData = filteredTransactions.reduce(
    (acc, transaction) => {
      const date = new Date(transaction.date)
      const month = format(date, "MMM yyyy")

      if (!acc[month]) {
        acc[month] = { month, income: 0, expense: 0 }
      }

      if (transaction.type === "income") {
        acc[month].income += transaction.amount
      } else {
        acc[month].expense += transaction.amount
      }

      return acc
    },
    {} as Record<string, { month: string; income: number; expense: number }>,
  )

  const monthlyChartData = Object.values(monthlyData)
    .map((data) => ({
      ...data,
      savings: data.income - data.expense,
      savingsRate: data.income > 0 ? ((data.income - data.expense) / data.income) * 100 : 0,
      expenseRatio: data.income > 0 ? (data.expense / data.income) * 100 : 0,
    }))
    .sort((a, b) => {
      const dateA = new Date(a.month)
      const dateB = new Date(b.month)
      return dateB.getTime() - dateA.getTime() // Most recent first
    })

  // Budget vs Actual data
  const budgetVsActualData = budgets
    .map((budget) => {
      const actualSpending = filteredTransactions
        .filter((t) => t.category === budget.name && t.type === "expense")
        .reduce((sum, t) => sum + t.amount, 0)

      const percentage = budget.amount > 0 ? (actualSpending / budget.amount) * 100 : 0
      const variance = budget.amount - actualSpending

      return {
        name: budget.name,
        budgeted: budget.amount,
        actual: actualSpending,
        percentage,
        variance,
      }
    })
    .sort((a, b) => b.actual - a.actual)

  // Investment performance data
  const investmentData = investments
    .map((investment) => {
      const progress = investment.targetAmount > 0 ? (investment.currentValue / investment.targetAmount) * 100 : 0

      return {
        name: investment.name,
        type: investment.type,
        currentValue: investment.currentValue,
        targetAmount: investment.targetAmount,
        progress,
      }
    })
    .sort((a, b) => b.progress - a.progress)

  // Export to PDF
  const exportToPDF = () => {
    try {
      const doc = new jsPDF()

      // Title
      doc.setFontSize(20)
      doc.setTextColor(128, 0, 128) // Purple color
      doc.text("Colina Financial Report", 105, 15, { align: "center" })

      // Subtitle
      doc.setFontSize(12)
      doc.setTextColor(0, 0, 0)
      doc.text(`Generated on: ${format(new Date(), "PPP")}`, 105, 25, { align: "center" })
      doc.text(`Period: ${format(dateRange.from, "PPP")} to ${format(dateRange.to, "PPP")}`, 105, 32, {
        align: "center",
      })

      // Summary section
      doc.setFontSize(16)
      doc.text("Financial Summary", 14, 45)

      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: 50,
        head: [["Metric", "Value"]],
        body: [
          ["Total Income", `${currency} ${totalIncome.toFixed(2)}`],
          ["Total Expenses", `${currency} ${totalExpenses.toFixed(2)}`],
          ["Net Savings", `${currency} ${netSavings.toFixed(2)}`],
          ["Savings Rate", `${savingsRate.toFixed(1)}%`],
          ["Total Investments", `${currency} ${totalInvestments.toFixed(2)}`],
          ["Investment Target Progress", `${investmentProgress.toFixed(1)}%`],
        ],
        theme: "grid",
        headStyles: { fillColor: [128, 0, 128] },
      })

      // Expense Categories
      const finalY1 = (doc as any).lastAutoTable.finalY + 10
      doc.setFontSize(16)
      doc.text("Expense Categories", 14, finalY1)

      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: finalY1 + 5,
        head: [["Category", "Amount", "Percentage"]],
        body: expenseCategoryData.map((category) => [
          category.name,
          `${currency} ${category.value.toFixed(2)}`,
          `${category.percentage.toFixed(1)}%`,
        ]),
        theme: "grid",
        headStyles: { fillColor: [128, 0, 128] },
      })

      // Transactions
      const finalY2 = (doc as any).lastAutoTable.finalY + 10
      doc.setFontSize(16)
      doc.text("Recent Transactions", 14, finalY2)

      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: finalY2 + 5,
        head: [["Date", "Description", "Type", "Amount"]],
        body: filteredTransactions
          .slice(0, 10)
          .map((t) => [
            format(new Date(t.date), "yyyy-MM-dd"),
            t.description,
            t.type,
            `${currency} ${t.amount.toFixed(2)}`,
          ]),
        theme: "grid",
        headStyles: { fillColor: [128, 0, 128] },
      })

      // Add a new page for investments
      doc.addPage()

      // Investments
      doc.setFontSize(16)
      doc.text("Investments", 14, 15)

      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: 20,
        head: [["Name", "Type", "Current Value", "Target", "Progress"]],
        body: investments.map((i) => [
          i.name,
          i.type,
          `${currency} ${i.currentValue.toFixed(2)}`,
          `${currency} ${i.targetAmount.toFixed(2)}`,
          `${((i.currentValue / i.targetAmount) * 100).toFixed(1)}%`,
        ]),
        theme: "grid",
        headStyles: { fillColor: [128, 0, 128] },
      })

      // Save the PDF
      doc.save("colina-financial-report.pdf")

      toast({
        title: "Export successful",
        description: "Your financial report has been exported to PDF",
      })
    } catch (error) {
      toast({
        title: "Export failed",
        description: "There was an error exporting your data",
        variant: "destructive",
      })
      console.error("Export error:", error)
    }
  }

  // Custom report components
  const ExpenseCategoryReport = () => {
    if (expenseCategoryData.length === 0) {
      return (
        <div className="flex items-center justify-center h-full">
          <p className="text-muted-foreground">No expense data available for the selected period</p>
        </div>
      )
    }

    const COLORS = ["#8b5cf6", "#a78bfa", "#c4b5fd", "#ddd6fe", "#7c3aed", "#6d28d9", "#5b21b6", "#4c1d95"]

    return (
      <div className="space-y-6">
        <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
          <h3 className="font-medium mb-4">Expense Distribution</h3>
          <div className="space-y-3">
            {expenseCategoryData.slice(0, 8).map((category, index) => (
              <div key={index}>
                <div className="flex justify-between mb-1">
                  <span className="font-medium">{category.name}</span>
                  <span>
                    {formatCurrency(category.value)} ({category.percentage.toFixed(1)}%)
                  </span>
                </div>
                <Progress
                  value={category.percentage}
                  className="h-3 bg-purple-100"
                  indicatorClassName="bg-purple-600"
                  style={
                    {
                      "--tw-bg-opacity": 1,
                      backgroundColor: COLORS[index % COLORS.length],
                    } as React.CSSProperties
                  }
                />
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-md border border-purple-200 dark:border-purple-800">
          <div className="grid grid-cols-3 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
            <div>Category</div>
            <div>Amount</div>
            <div>Percentage</div>
          </div>
          <div className="divide-y divide-purple-200 dark:divide-purple-800">
            {expenseCategoryData.map((category, index) => (
              <div key={index} className="grid grid-cols-3 px-4 py-3">
                <div className="font-medium">{category.name}</div>
                <div>{formatCurrency(category.value)}</div>
                <div>{category.percentage.toFixed(1)}%</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const MonthlyComparisonReport = () => {
    if (monthlyChartData.length === 0) {
      return (
        <div className="flex items-center justify-center h-full">
          <p className="text-muted-foreground">No data available for the selected period</p>
        </div>
      )
    }

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
            <h3 className="font-medium mb-2">Income vs Expenses</h3>
            <div className="space-y-4 mt-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span>Income</span>
                  <span>{formatCurrency(totalIncome)}</span>
                </div>
                <Progress value={100} className="h-3 bg-purple-100" indicatorClassName="bg-green-500" />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>Expenses</span>
                  <span>{formatCurrency(totalExpenses)}</span>
                </div>
                <Progress
                  value={totalIncome > 0 ? (totalExpenses / totalIncome) * 100 : 0}
                  className="h-3 bg-purple-100"
                  indicatorClassName="bg-red-500"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>Savings</span>
                  <span className={netSavings >= 0 ? "text-green-600" : "text-red-600"}>
                    {netSavings >= 0 ? "+" : ""}
                    {formatCurrency(netSavings)}
                  </span>
                </div>
                <Progress
                  value={savingsRate > 0 ? savingsRate : 0}
                  className="h-3 bg-purple-100"
                  indicatorClassName="bg-purple-600"
                />
                <p className="text-xs text-right mt-1">Savings Rate: {savingsRate.toFixed(1)}%</p>
              </div>
            </div>
          </div>

          <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
            <h3 className="font-medium mb-2">Monthly Trend</h3>
            <div className="space-y-3 mt-4">
              {monthlyChartData.slice(0, 3).map((month, index) => (
                <div key={index} className="border-b border-purple-200 dark:border-purple-800 pb-2 last:border-0">
                  <p className="font-medium">{month.month}</p>
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <div>
                      <p className="text-xs text-muted-foreground">Income</p>
                      <p>{formatCurrency(month.income)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Expenses</p>
                      <p>{formatCurrency(month.expense)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Savings</p>
                      <p className={month.savings >= 0 ? "text-green-600" : "text-red-600"}>
                        {month.savings >= 0 ? "+" : ""}
                        {formatCurrency(month.savings)}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Savings Rate</p>
                      <p>{month.savingsRate.toFixed(1)}%</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-md border border-purple-200 dark:border-purple-800">
          <div className="grid grid-cols-5 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
            <div>Month</div>
            <div>Income</div>
            <div>Expenses</div>
            <div>Savings</div>
            <div>Savings Rate</div>
          </div>
          <div className="divide-y divide-purple-200 dark:divide-purple-800">
            {monthlyChartData.map((month, index) => (
              <div key={index} className="grid grid-cols-5 px-4 py-3">
                <div className="font-medium">{month.month}</div>
                <div>{formatCurrency(month.income)}</div>
                <div>{formatCurrency(month.expense)}</div>
                <div className={month.savings >= 0 ? "text-green-600" : "text-red-600"}>
                  {month.savings >= 0 ? "+" : ""}
                  {formatCurrency(month.savings)}
                </div>
                <div className="flex items-center gap-2">
                  <Progress
                    value={month.savingsRate > 0 ? month.savingsRate : 0}
                    className="h-2 w-24 bg-purple-100"
                    indicatorClassName={
                      month.savingsRate < 0 ? "bg-red-500" : month.savingsRate > 20 ? "bg-green-500" : "bg-amber-500"
                    }
                  />
                  <span className="text-xs">{month.savingsRate.toFixed(1)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const BudgetVsActualReport = () => {
    if (budgetVsActualData.length === 0) {
      return (
        <div className="flex items-center justify-center h-full">
          <p className="text-muted-foreground">No budget data available</p>
        </div>
      )
    }

    return (
      <div className="space-y-6">
        <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
          <h3 className="font-medium mb-4">Budget Performance</h3>
          <div className="space-y-4">
            {budgetVsActualData.slice(0, 5).map((budget, index) => (
              <div key={index}>
                <div className="flex justify-between mb-1">
                  <span className="font-medium">{budget.name}</span>
                  <span>
                    {formatCurrency(budget.actual)} / {formatCurrency(budget.budgeted)}
                  </span>
                </div>
                <Progress
                  value={budget.percentage}
                  className="h-3 bg-purple-100"
                  indicatorClassName={
                    budget.percentage > 100 ? "bg-red-500" : budget.percentage > 80 ? "bg-amber-500" : "bg-green-500"
                  }
                />
                <div className="flex justify-between mt-1">
                  <span className="text-xs">{budget.percentage.toFixed(0)}% used</span>
                  <span className={`text-xs ${budget.variance >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {budget.variance >= 0
                      ? `${formatCurrency(budget.variance)} remaining`
                      : `${formatCurrency(Math.abs(budget.variance))} over budget`}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-md border border-purple-200 dark:border-purple-800">
          <div className="grid grid-cols-5 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
            <div>Category</div>
            <div>Budget</div>
            <div>Actual</div>
            <div>Variance</div>
            <div>% Used</div>
          </div>
          <div className="divide-y divide-purple-200 dark:divide-purple-800">
            {budgetVsActualData.map((budget, index) => (
              <div key={index} className="grid grid-cols-5 px-4 py-3">
                <div className="font-medium">{budget.name}</div>
                <div>{formatCurrency(budget.budgeted)}</div>
                <div>{formatCurrency(budget.actual)}</div>
                <div className={budget.variance >= 0 ? "text-green-600" : "text-red-600"}>
                  {budget.variance >= 0 ? "+" : ""}
                  {formatCurrency(budget.variance)}
                </div>
                <div className="flex items-center gap-2">
                  <Progress
                    value={budget.percentage}
                    className="h-2 w-24 bg-purple-100"
                    indicatorClassName={
                      budget.percentage > 100 ? "bg-red-500" : budget.percentage > 80 ? "bg-amber-500" : "bg-green-500"
                    }
                  />
                  <span className="text-xs">{budget.percentage.toFixed(0)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const IncomeVsExpenseReport = () => {
    if (totalIncome === 0 && totalExpenses === 0) {
      return (
        <div className="flex items-center justify-center h-full">
          <p className="text-muted-foreground">No income or expense data available</p>
        </div>
      )
    }

    const expenseRatio = totalIncome > 0 ? (totalExpenses / totalIncome) * 100 : 0

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
            <h3 className="font-medium mb-4">Income vs Expense Breakdown</h3>

            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span>Income</span>
                  <span>{formatCurrency(totalIncome)}</span>
                </div>
                <Progress value={100} className="h-3 bg-purple-100" indicatorClassName="bg-green-500" />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>Expenses</span>
                  <span>{formatCurrency(totalExpenses)}</span>
                </div>
                <Progress value={expenseRatio} className="h-3 bg-purple-100" indicatorClassName="bg-red-500" />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>Savings</span>
                  <span className={netSavings >= 0 ? "text-green-600" : "text-red-600"}>
                    {netSavings >= 0 ? "+" : ""}
                    {formatCurrency(netSavings)}
                  </span>
                </div>
                <Progress
                  value={savingsRate > 0 ? savingsRate : 0}
                  className="h-3 bg-purple-100"
                  indicatorClassName="bg-purple-600"
                />
                <p className="text-xs text-right mt-1">Savings Rate: {savingsRate.toFixed(1)}%</p>
              </div>
            </div>
          </div>

          <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
            <h3 className="font-medium mb-2">Financial Health</h3>
            <div className="flex items-center justify-center h-40">
              <div className="w-40 h-40 rounded-full border-8 border-purple-600 relative flex items-center justify-center">
                <div
                  className="absolute inset-0 rounded-full bg-red-500"
                  style={{
                    clipPath: `inset(0 0 0 ${100 - expenseRatio > 0 ? 100 - expenseRatio : 0}%)`,
                  }}
                ></div>
                <div className="z-10 text-center">
                  <p className="text-lg font-bold">{expenseRatio.toFixed(0)}%</p>
                  <p className="text-xs">Expense Ratio</p>
                </div>
              </div>
            </div>
            <p className="text-center text-sm mt-2">
              {expenseRatio <= 100
                ? `You're spending ${expenseRatio.toFixed(0)}% of your income`
                : `You're spending ${expenseRatio.toFixed(0)}% of your income (overspending)`}
            </p>
          </div>
        </div>

        <div className="rounded-md border border-purple-200 dark:border-purple-800">
          <div className="grid grid-cols-4 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
            <div>Month</div>
            <div>Income</div>
            <div>Expenses</div>
            <div>Expense Ratio</div>
          </div>
          <div className="divide-y divide-purple-200 dark:divide-purple-800">
            {monthlyChartData.map((month, index) => (
              <div key={index} className="grid grid-cols-4 px-4 py-3">
                <div className="font-medium">{month.month}</div>
                <div>{formatCurrency(month.income)}</div>
                <div>{formatCurrency(month.expense)}</div>
                <div className="flex items-center gap-2">
                  <Progress
                    value={month.expenseRatio}
                    max={150}
                    className="h-2 w-24 bg-purple-100"
                    indicatorClassName={
                      month.expenseRatio > 100
                        ? "bg-red-500"
                        : month.expenseRatio > 80
                          ? "bg-amber-500"
                          : "bg-green-500"
                    }
                  />
                  <span className="text-xs">{month.expenseRatio.toFixed(0)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const InvestmentProgressReport = () => {
    if (investmentData.length === 0) {
      return (
        <div className="flex items-center justify-center h-full">
          <p className="text-muted-foreground">No investment data available</p>
        </div>
      )
    }

    return (
      <div className="space-y-6">
        <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
          <h3 className="font-medium mb-4">Investment Progress</h3>
          <div className="space-y-4">
            {investmentData.slice(0, 5).map((investment, index) => (
              <div key={index}>
                <div className="flex justify-between mb-1">
                  <span className="font-medium">{investment.name}</span>
                  <span>
                    {formatCurrency(investment.currentValue)} / {formatCurrency(investment.targetAmount)}
                  </span>
                </div>
                <Progress
                  value={investment.progress}
                  className="h-3 bg-purple-100"
                  indicatorClassName="bg-purple-600"
                />
                <p className="text-xs text-right mt-1">{investment.progress.toFixed(1)}% of target</p>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-md border border-purple-200 dark:border-purple-800">
          <div className="grid grid-cols-4 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
            <div>Name</div>
            <div>Type</div>
            <div>Current Value</div>
            <div>Progress</div>
          </div>
          <div className="divide-y divide-purple-200 dark:divide-purple-800">
            {investmentData.map((investment, index) => (
              <div key={index} className="grid grid-cols-4 px-4 py-3">
                <div className="font-medium">{investment.name}</div>
                <div>{investment.type}</div>
                <div>{formatCurrency(investment.currentValue)}</div>
                <div className="flex items-center gap-2">
                  <Progress
                    value={investment.progress}
                    className="h-2 w-24 bg-purple-100"
                    indicatorClassName="bg-purple-600"
                  />
                  <span className="text-xs">{investment.progress.toFixed(0)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-t-purple-600 border-purple-200 rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-purple-700 dark:text-purple-300">Loading report data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold tracking-tight text-purple-700 dark:text-purple-300">Reports</h2>
        <div className="flex flex-col sm:flex-row gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                id="date"
                variant={"outline"}
                className={cn(
                  "w-full sm:w-[300px] justify-start text-left font-normal",
                  !dateRange && "text-muted-foreground",
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateRange?.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                    </>
                  ) : (
                    format(dateRange.from, "LLL dd, y")
                  )
                ) : (
                  <span>Pick a date</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={dateRange?.from}
                selected={dateRange}
                onSelect={(range) => range && setDateRange(range)}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>
          <Select value={reportType} onValueChange={setReportType}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="Select report type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="expense-category">Expenses by Category</SelectItem>
              <SelectItem value="monthly">Monthly Comparison</SelectItem>
              <SelectItem value="budget-actual">Budget vs. Actual</SelectItem>
              <SelectItem value="income-expense">Income vs. Expense</SelectItem>
              <SelectItem value="investment-progress">Investment Progress</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Total Income</CardTitle>
            <CardDescription>For selected period</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {currency} {totalIncome.toFixed(2)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Total Expenses</CardTitle>
            <CardDescription>For selected period</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {currency} {totalExpenses.toFixed(2)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Net Savings</CardTitle>
            <CardDescription>Income - Expenses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${netSavings >= 0 ? "text-green-600" : "text-red-600"}`}>
              {currency} {netSavings.toFixed(2)}
            </div>
            <div className="text-sm mt-1">Savings Rate: {savingsRate.toFixed(1)}%</div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col sm:flex-row gap-2 justify-end">
        <Button variant="outline" onClick={exportToPDF} className="flex items-center">
          <Download className="mr-2 h-4 w-4" />
          Export to PDF
        </Button>
      </div>

      <Tabs defaultValue="reports" className="space-y-4">
        <TabsList className="bg-purple-100 dark:bg-purple-900/50">
          <TabsTrigger value="reports" className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800">
            Reports
          </TabsTrigger>
          <TabsTrigger value="tables" className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800">
            Tables
          </TabsTrigger>
        </TabsList>
        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-purple-700 dark:text-purple-300">
                {reportType === "expense-category" && "Expenses by Category"}
                {reportType === "monthly" && "Monthly Comparison"}
                {reportType === "budget-actual" && "Budget vs. Actual Spending"}
                {reportType === "income-expense" && "Income vs. Expenses"}
                {reportType === "investment-progress" && "Investment Progress"}
              </CardTitle>
              <CardDescription>
                {reportType === "expense-category" && "Breakdown of your expenses by category"}
                {reportType === "monthly" && "Compare your spending month by month"}
                {reportType === "budget-actual" && "Compare your budgeted amounts with actual spending"}
                {reportType === "income-expense" && "Compare your income and expenses over time"}
                {reportType === "investment-progress" && "Track progress towards your investment goals"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {reportType === "expense-category" && <ExpenseCategoryReport />}
              {reportType === "monthly" && <MonthlyComparisonReport />}
              {reportType === "budget-actual" && <BudgetVsActualReport />}
              {reportType === "income-expense" && <IncomeVsExpenseReport />}
              {reportType === "investment-progress" && <InvestmentProgressReport />}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="tables" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Expense Categories</CardTitle>
              <CardDescription>Breakdown of expenses by category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border border-purple-200 dark:border-purple-800">
                <div className="grid grid-cols-3 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
                  <div>Category</div>
                  <div>Amount</div>
                  <div>% of Total</div>
                </div>
                <div className="divide-y divide-purple-200 dark:divide-purple-800">
                  {expenseCategoryData.length > 0 ? (
                    expenseCategoryData.map((category, index) => (
                      <div key={index} className="grid grid-cols-3 px-4 py-3">
                        <div>{category.name}</div>
                        <div>
                          {currency} {category.value.toFixed(2)}
                        </div>
                        <div>{category.percentage.toFixed(1)}%</div>
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-3 text-center text-muted-foreground">No expense data available</div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Your most recent financial activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border border-purple-200 dark:border-purple-800">
                <div className="grid grid-cols-4 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
                  <div>Date</div>
                  <div>Description</div>
                  <div>Type</div>
                  <div>Amount</div>
                </div>
                <div className="divide-y divide-purple-200 dark:divide-purple-800">
                  {filteredTransactions.length > 0 ? (
                    filteredTransactions.slice(0, 10).map((transaction, index) => (
                      <div key={index} className="grid grid-cols-4 px-4 py-3">
                        <div>{format(new Date(transaction.date), "MMM dd, yyyy")}</div>
                        <div>{transaction.description}</div>
                        <div
                          className={`capitalize ${transaction.type === "income" ? "text-green-600" : "text-red-600"}`}
                        >
                          {transaction.type}
                        </div>
                        <div className={transaction.type === "income" ? "text-green-600" : "text-red-600"}>
                          {currency} {transaction.amount.toFixed(2)}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-3 text-center text-muted-foreground">No transaction data available</div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Investment Progress</CardTitle>
              <CardDescription>Track your investment goals</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border border-purple-200 dark:border-purple-800">
                <div className="grid grid-cols-5 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
                  <div>Name</div>
                  <div>Type</div>
                  <div>Current Value</div>
                  <div>Target</div>
                  <div>Progress</div>
                </div>
                <div className="divide-y divide-purple-200 dark:divide-purple-800">
                  {investments.length > 0 ? (
                    investments.map((investment, index) => (
                      <div key={index} className="grid grid-cols-5 px-4 py-3">
                        <div>{investment.name}</div>
                        <div>{investment.type}</div>
                        <div>
                          {currency} {investment.currentValue.toFixed(2)}
                        </div>
                        <div>
                          {currency} {investment.targetAmount.toFixed(2)}
                        </div>
                        <div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                            <div
                              className="bg-purple-600 h-2.5 rounded-full"
                              style={{
                                width: `${Math.min(100, (investment.currentValue / investment.targetAmount) * 100)}%`,
                              }}
                            ></div>
                          </div>
                          <span className="text-xs mt-1 inline-block">
                            {((investment.currentValue / investment.targetAmount) * 100).toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-3 text-center text-muted-foreground">No investment data available</div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
