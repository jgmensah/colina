"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { type User, getUser, setUser, generateId, initializeLocalStorage } from "@/lib/local-storage"

type AuthContextType = {
  user: User | null
  loading: boolean
  signIn: (phoneNumber: string, pin: string) => Promise<{ error?: string }>
  signUp: (fullName: string, phoneNumber: string, pin: string) => Promise<{ error?: string }>
  signOut: () => void
  updateUserProfile: (updates: Partial<User>) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setCurrentUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Initialize local storage with sample data if needed
    if (typeof window !== "undefined") {
      initializeLocalStorage()
      const storedUser = getUser()
      setCurrentUser(storedUser)
      setLoading(false)
    }
  }, [])

  const signIn = async (phoneNumber: string, pin: string) => {
    // In a real app, we would validate credentials
    // For this demo, we'll just check if the user exists and use the PIN as a simple check
    const storedUser = getUser()

    if (storedUser && storedUser.phoneNumber === phoneNumber) {
      // In a real app, we would verify the PIN
      setCurrentUser(storedUser)
      router.push("/dashboard")
      return {}
    }

    return { error: "Invalid phone number or PIN" }
  }

  const signUp = async (fullName: string, phoneNumber: string, pin: string) => {
    // Create a new user
    const newUser: User = {
      id: generateId(),
      fullName,
      phoneNumber,
      createdAt: new Date().toISOString(),
    }

    setUser(newUser)
    setCurrentUser(newUser)
    router.push("/dashboard")
    return {}
  }

  const signOut = () => {
    // In a real app, we might want to keep the data but just log out
    // For simplicity, we'll just clear the user
    setCurrentUser(null)
    router.push("/signin")
  }

  const updateUserProfile = (updates: Partial<User>) => {
    if (!user) return

    const updatedUser = { ...user, ...updates }
    setUser(updatedUser)
    setCurrentUser(updatedUser)
  }

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, updateUserProfile }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
