import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number, currency = "GHS"): string {
  const currencyConfig: Record<string, { code: string; symbol: string }> = {
    GHS: { code: "GHS", symbol: "₵" },
    NGN: { code: "NGN", symbol: "₦" },
    EUR: { code: "EUR", symbol: "€" },
    GBP: { code: "GBP", symbol: "£" },
    USD: { code: "USD", symbol: "$" },
  }

  const config = currencyConfig[currency] || currencyConfig.GHS

  return new Intl.NumberFormat("en", {
    style: "currency",
    currency: config.code,
    currencyDisplay: "symbol",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}
