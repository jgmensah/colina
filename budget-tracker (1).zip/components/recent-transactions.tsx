import { ArrowDownLeft, ArrowUpRight } from "lucide-react"
import { cn, formatCurrency } from "@/lib/utils"
import { format } from "date-fns"
import type { Budget, Transaction } from "@/lib/local-storage"

interface RecentTransactionsProps {
  transactions: Transaction[]
  budgets: Budget[]
  limit?: number
}

export function RecentTransactions({ transactions, budgets, limit }: RecentTransactionsProps) {
  const displayTransactions = limit ? transactions.slice(0, limit) : transactions

  if (displayTransactions.length === 0) {
    return <div className="text-center py-4 text-muted-foreground">No transactions found</div>
  }

  return (
    <div className="space-y-4">
      {displayTransactions.map((transaction) => {
        const budget = budgets.find((b) => b.id === transaction.budgetId)

        return (
          <div key={transaction.id} className="flex items-center">
            <div
              className={cn(
                "flex h-9 w-9 items-center justify-center rounded-full",
                transaction.type === "income" ? "bg-purple-100" : "bg-red-100",
              )}
            >
              {transaction.type === "income" ? (
                <ArrowUpRight className="h-4 w-4 text-purple-600" />
              ) : (
                <ArrowDownLeft className="h-4 w-4 text-red-500" />
              )}
            </div>
            <div className="ml-4 space-y-1">
              <p className="text-sm font-medium leading-none">{transaction.description}</p>
              <p className="text-xs text-muted-foreground">
                {format(new Date(transaction.date), "MMM d, yyyy")} • {budget?.name || transaction.category}
              </p>
            </div>
            <div
              className={cn("ml-auto font-medium", transaction.type === "income" ? "text-purple-600" : "text-red-500")}
            >
              {transaction.type === "income" ? "+" : "-"}
              {formatCurrency(transaction.amount)}
            </div>
          </div>
        )
      })}
    </div>
  )
}
