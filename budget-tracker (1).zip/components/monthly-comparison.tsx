"use client"

import { eachMonthOfInterval, endOfMonth, format, startOfMonth, subMonths } from "date-fns"
import { formatCurrency } from "@/lib/utils"
import type { Transaction } from "@/lib/local-storage"
import { Progress } from "@/components/ui/progress"

interface MonthlyComparisonProps {
  transactions: Transaction[]
}

export function MonthlyComparison({ transactions }: MonthlyComparisonProps) {
  // Generate data for the last 6 months
  const today = new Date()
  const sixMonthsAgo = subMonths(today, 5)

  const months = eachMonthOfInterval({
    start: sixMonthsAgo,
    end: today,
  })

  const monthlyData = months
    .map((month) => {
      const monthStart = startOfMonth(month)
      const monthEnd = endOfMonth(month)
      const monthName = format(month, "MMM yyyy")

      const monthTransactions = transactions.filter((t) => {
        const date = new Date(t.date)
        return date >= monthStart && date <= monthEnd
      })

      const income = monthTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
      const expenses = monthTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)
      const savings = income - expenses
      const savingsRate = income > 0 ? (savings / income) * 100 : 0

      return {
        month: monthName,
        income,
        expenses,
        savings,
        savingsRate,
      }
    })
    .reverse() // Show most recent month first

  if (monthlyData.every((item) => item.income === 0 && item.expenses === 0)) {
    return (
      <div className="flex items-center justify-center h-[350px] text-muted-foreground">
        No transaction data available for the selected period
      </div>
    )
  }

  // Calculate totals
  const totalIncome = monthlyData.reduce((sum, month) => sum + month.income, 0)
  const totalExpenses = monthlyData.reduce((sum, month) => sum + month.expenses, 0)
  const totalSavings = totalIncome - totalExpenses
  const overallSavingsRate = totalIncome > 0 ? (totalSavings / totalIncome) * 100 : 0

  return (
    <div className="space-y-6">
      <div className="rounded-md border border-purple-200 dark:border-purple-800">
        <div className="grid grid-cols-5 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
          <div>Month</div>
          <div>Income</div>
          <div>Expenses</div>
          <div>Savings</div>
          <div>Savings Rate</div>
        </div>
        <div className="divide-y divide-purple-200 dark:divide-purple-800">
          {monthlyData.map((month, index) => (
            <div key={index} className="grid grid-cols-5 px-4 py-3">
              <div className="font-medium">{month.month}</div>
              <div>{formatCurrency(month.income)}</div>
              <div>{formatCurrency(month.expenses)}</div>
              <div className={month.savings >= 0 ? "text-green-600" : "text-red-600"}>
                {month.savings >= 0 ? "+" : ""}
                {formatCurrency(month.savings)}
              </div>
              <div className="flex items-center gap-2">
                <Progress
                  value={month.savingsRate}
                  className="h-2 w-24 bg-purple-100"
                  indicatorClassName={
                    month.savingsRate < 0 ? "bg-red-500" : month.savingsRate > 20 ? "bg-green-500" : "bg-amber-500"
                  }
                />
                <span className="text-xs">{month.savingsRate.toFixed(0)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
        <h3 className="font-medium mb-2">6-Month Summary</h3>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Total Income</p>
            <p className="text-lg font-medium">{formatCurrency(totalIncome)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Expenses</p>
            <p className="text-lg font-medium">{formatCurrency(totalExpenses)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Savings</p>
            <p className={`text-lg font-medium ${totalSavings >= 0 ? "text-green-600" : "text-red-600"}`}>
              {totalSavings >= 0 ? "+" : ""}
              {formatCurrency(totalSavings)}
            </p>
            <p className="text-xs text-muted-foreground">Savings Rate: {overallSavingsRate.toFixed(1)}%</p>
          </div>
        </div>
      </div>
    </div>
  )
}
