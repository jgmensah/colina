"use client"

import { useState, useEffect } from "react"
import { format } from "date-fns"
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/components/auth-provider"
import { getBudgets, getTransactions, getInvestments } from "@/lib/local-storage"

export default function ChartsPage() {
  const { user } = useAuth()
  const [transactions, setTransactions] = useState<any[]>([])
  const [budgets, setBudgets] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    const fetchData = () => {
      setLoading(true)
      const budgetData = getBudgets().filter((b) => b.userId === user.id)
      const transactionData = getTransactions().filter((t) => t.userId === user.id)
      const investmentData = getInvestments().filter((i) => i.userId === user.id)

      setBudgets(budgetData)
      setTransactions(transactionData)
      setLoading(false)
    }

    fetchData()
  }, [user])

  // Calculate summary data
  const totalIncome = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
  const totalExpenses = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

  // Group expenses by category
  const expensesByCategory = transactions
    .filter((t) => t.type === "expense")
    .reduce(
      (acc, transaction) => {
        const category = transaction.category
        if (!acc[category]) {
          acc[category] = 0
        }
        acc[category] += transaction.amount
        return acc
      },
      {} as Record<string, number>,
    )

  const expenseCategoryData = Object.entries(expensesByCategory).map(([name, value]) => ({
    name,
    value,
  }))

  // Group transactions by month
  const monthlyData = transactions.reduce(
    (acc, transaction) => {
      const date = new Date(transaction.date)
      const month = format(date, "MMM yyyy")

      if (!acc[month]) {
        acc[month] = { month, income: 0, expense: 0 }
      }

      if (transaction.type === "income") {
        acc[month].income += transaction.amount
      } else {
        acc[month].expense += transaction.amount
      }

      return acc
    },
    {} as Record<string, { month: string; income: number; expense: number }>,
  )

  const monthlyChartData = Object.values(monthlyData)

  // Budget vs Actual data
  const budgetVsActualData = budgets.map((budget) => {
    const actualSpending = transactions
      .filter((t) => t.budgetId === budget.id && t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0)

    return {
      name: budget.name,
      budgeted: budget.amount,
      actual: actualSpending,
    }
  })

  // Income vs Expense data
  const incomeVsExpenseData = [
    { name: "Income", value: totalIncome },
    { name: "Expense", value: totalExpenses },
  ]

  const COLORS = ["#8b5cf6", "#a78bfa", "#c4b5fd", "#ddd6fe", "#7c3aed", "#6d28d9", "#5b21b6", "#4c1d95"]

  if (loading) {
    return <div className="p-8">Loading...</div>
  }

  return (
    <div className="p-8 space-y-8">
      <h1 className="text-3xl font-bold">Charts Test Page</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Expense Category Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Expenses by Category</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={expenseCategoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {expenseCategoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `GHS ${Number(value).toFixed(2)}`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Monthly Comparison Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Comparison</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyChartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => `GHS ${Number(value).toFixed(2)}`} />
                <Legend />
                <Bar dataKey="income" name="Income" fill="#82ca9d" />
                <Bar dataKey="expense" name="Expense" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Budget vs Actual Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Budget vs Actual</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={budgetVsActualData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => `GHS ${Number(value).toFixed(2)}`} />
                <Legend />
                <Bar dataKey="budgeted" name="Budgeted" fill="#8b5cf6" />
                <Bar dataKey="actual" name="Actual" fill="#c4b5fd" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Income vs Expense Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Income vs Expense</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={incomeVsExpenseData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  <Cell fill="#82ca9d" />
                  <Cell fill="#8b5cf6" />
                </Pie>
                <Tooltip formatter={(value) => `GHS ${Number(value).toFixed(2)}`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
