"use client"

import { formatCurrency } from "@/lib/utils"
import type { Investment } from "@/lib/local-storage"
import { Progress } from "@/components/ui/progress"

interface InvestmentPerformanceProps {
  investments: Investment[]
}

export function InvestmentPerformance({ investments }: InvestmentPerformanceProps) {
  // Process data for the display
  const investmentData = investments
    .map((investment) => {
      const gain = investment.currentValue - investment.initialInvestment
      const returnPercentage = investment.initialInvestment > 0 ? (gain / investment.initialInvestment) * 100 : 0
      const progress = investment.targetAmount > 0 ? (investment.currentValue / investment.targetAmount) * 100 : 0

      return {
        id: investment.id,
        name: investment.name,
        type: investment.type,
        initial: investment.initialInvestment,
        current: investment.currentValue,
        target: investment.targetAmount,
        gain: gain,
        returnPercentage: returnPercentage,
        progress: progress,
      }
    })
    .sort((a, b) => b.current - a.current)

  if (investmentData.length === 0) {
    return (
      <div className="flex items-center justify-center h-[350px] text-muted-foreground">
        No investment data available
      </div>
    )
  }

  // Calculate totals
  const totalInitial = investmentData.reduce((sum, inv) => sum + inv.initial, 0)
  const totalCurrent = investmentData.reduce((sum, inv) => sum + inv.current, 0)
  const totalTarget = investmentData.reduce((sum, inv) => sum + inv.target, 0)
  const totalGain = totalCurrent - totalInitial
  const totalReturnPercentage = totalInitial > 0 ? (totalGain / totalInitial) * 100 : 0
  const totalProgress = totalTarget > 0 ? (totalCurrent / totalTarget) * 100 : 0

  return (
    <div className="space-y-6">
      <div className="rounded-md border border-purple-200 dark:border-purple-800">
        <div className="grid grid-cols-6 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
          <div>Name</div>
          <div>Initial</div>
          <div>Current</div>
          <div>Target</div>
          <div>Return</div>
          <div>Progress</div>
        </div>
        <div className="divide-y divide-purple-200 dark:divide-purple-800">
          {investmentData.map((investment) => (
            <div key={investment.id} className="grid grid-cols-6 px-4 py-3">
              <div className="font-medium">{investment.name}</div>
              <div>{formatCurrency(investment.initial)}</div>
              <div>{formatCurrency(investment.current)}</div>
              <div>{formatCurrency(investment.target)}</div>
              <div className={investment.gain >= 0 ? "text-green-600" : "text-red-600"}>
                {investment.gain >= 0 ? "+" : ""}
                {formatCurrency(investment.gain)} ({investment.returnPercentage.toFixed(1)}%)
              </div>
              <div className="flex items-center gap-2">
                <Progress
                  value={investment.progress}
                  className="h-2 w-24 bg-purple-100"
                  indicatorClassName="bg-purple-600"
                />
                <span className="text-xs">{investment.progress.toFixed(0)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
        <h3 className="font-medium mb-2">Investment Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Total Investment</p>
            <p className="text-lg font-medium">{formatCurrency(totalInitial)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Current Value</p>
            <p className="text-lg font-medium">{formatCurrency(totalCurrent)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Return</p>
            <p className={`text-lg font-medium ${totalGain >= 0 ? "text-green-600" : "text-red-600"}`}>
              {totalGain >= 0 ? "+" : ""}
              {formatCurrency(totalGain)} ({totalReturnPercentage.toFixed(1)}%)
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Target Progress</p>
            <div className="flex items-center gap-2 mt-1">
              <Progress value={totalProgress} className="h-2 w-24 bg-purple-100" indicatorClassName="bg-purple-600" />
              <span className="text-xs">{totalProgress.toFixed(0)}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
