"use client"

import { useState } from "react"
import Link from "next/link"
import { Edit, Plus, Trash } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { BudgetData, TransactionData } from "@/lib/data"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"

export default function BudgetsPage() {
  const [budgets, setBudgets] = useState(BudgetData)

  const handleDelete = (id: string) => {
    setBudgets(budgets.filter((budget) => budget.id !== id))
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Budgets" text="Manage your budget categories">
        <Link href="/budgets/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Budget
          </Button>
        </Link>
      </DashboardHeader>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {budgets.map((budget) => {
          const spent = TransactionData.filter((t) => t.budgetId === budget.id && t.type === "expense").reduce(
            (sum, t) => sum + t.amount,
            0,
          )
          const percentage = (spent / budget.amount) * 100

          return (
            <Card key={budget.id} className="border-purple-200 shadow-md dark:border-purple-800">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-purple-700 dark:text-purple-300">{budget.name}</CardTitle>
                  <div className="flex space-x-2">
                    <Link href={`/budgets/${budget.id}/edit`}>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-purple-600 hover:bg-purple-100 dark:text-purple-400 dark:hover:bg-purple-900/50"
                      >
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Edit</span>
                      </Button>
                    </Link>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(budget.id)}
                      className="text-purple-600 hover:bg-purple-100 dark:text-purple-400 dark:hover:bg-purple-900/50"
                    >
                      <Trash className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </div>
                </div>
                <CardDescription>{budget.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">
                    ${spent.toFixed(2)} / ${budget.amount.toFixed(2)}
                  </span>
                  <span
                    className={`text-sm font-medium ${percentage > 100 ? "text-red-500" : percentage > 80 ? "text-amber-500" : "text-purple-600"}`}
                  >
                    {percentage.toFixed(0)}%
                  </span>
                </div>
                <Progress
                  value={percentage}
                  className={`h-2 ${percentage > 100 ? "bg-red-200" : "bg-purple-100"}`}
                  indicatorClassName={
                    percentage > 100 ? "bg-red-500" : percentage > 80 ? "bg-amber-500" : "bg-purple-600"
                  }
                />
                <p className="text-xs text-muted-foreground mt-2">
                  {percentage > 100
                    ? `Over budget by $${(spent - budget.amount).toFixed(2)}`
                    : `${budget.amount - spent > 0 ? `$${(budget.amount - spent).toFixed(2)} remaining` : "Budget depleted"}`}
                </p>
              </CardContent>
              <CardFooter>
                <Link href={`/budgets/${budget.id}`} className="w-full">
                  <Button
                    variant="outline"
                    className="w-full border-purple-300 text-purple-700 hover:bg-purple-100 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-900/50"
                  >
                    View Details
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          )
        })}
      </div>
    </DashboardShell>
  )
}
