"use client"

import { formatCurrency } from "@/lib/utils"
import type { Budget, Transaction } from "@/lib/local-storage"
import { Progress } from "@/components/ui/progress"

interface BudgetOverviewProps {
  budgets: Budget[]
  transactions: Transaction[]
}

export function BudgetOverview({ budgets, transactions }: BudgetOverviewProps) {
  // Process data for the display
  const budgetData = budgets.map((budget) => {
    const spent = transactions
      .filter((t) => t.budgetId === budget.id && t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0)

    const percentage = budget.amount > 0 ? (spent / budget.amount) * 100 : 0

    return {
      name: budget.name,
      budget: budget.amount,
      spent: spent,
      percentage: percentage,
      remaining: budget.amount - spent,
    }
  })

  if (budgetData.length === 0) {
    return (
      <div className="flex items-center justify-center h-[350px] text-muted-foreground">No budget data available</div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="rounded-md border border-purple-200 dark:border-purple-800">
        <div className="grid grid-cols-4 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
          <div>Budget</div>
          <div>Allocated</div>
          <div>Spent</div>
          <div>Progress</div>
        </div>
        <div className="divide-y divide-purple-200 dark:divide-purple-800">
          {budgetData.map((item, index) => (
            <div key={index} className="grid grid-cols-4 px-4 py-3">
              <div className="font-medium">{item.name}</div>
              <div>{formatCurrency(item.budget)}</div>
              <div>{formatCurrency(item.spent)}</div>
              <div className="flex items-center gap-2">
                <Progress
                  value={item.percentage}
                  className="h-2 w-24 bg-purple-100"
                  indicatorClassName={
                    item.percentage > 100 ? "bg-red-500" : item.percentage > 80 ? "bg-amber-500" : "bg-purple-600"
                  }
                />
                <span className="text-xs">{item.percentage.toFixed(0)}%</span>
                <span className="text-xs text-muted-foreground ml-2">
                  {item.remaining >= 0
                    ? `${formatCurrency(item.remaining)} left`
                    : `${formatCurrency(Math.abs(item.remaining))} over`}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
        <h3 className="font-medium mb-2">Summary</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Total Budget</p>
            <p className="text-lg font-medium">
              {formatCurrency(budgetData.reduce((sum, item) => sum + item.budget, 0))}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Spent</p>
            <p className="text-lg font-medium">
              {formatCurrency(budgetData.reduce((sum, item) => sum + item.spent, 0))}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export function BudgetVsActual({ budgets, transactions }: { budgets: Budget[]; transactions: Transaction[] }) {
  // Process data for the display
  const budgetData = budgets.map((budget) => {
    const spent = transactions
      .filter((t) => t.budgetId === budget.id && t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0)

    const percentage = budget.amount > 0 ? (spent / budget.amount) * 100 : 0
    const variance = budget.amount - spent

    return {
      name: budget.name,
      budget: budget.amount,
      actual: spent,
      percentage: percentage,
      variance: variance,
    }
  })

  if (budgetData.length === 0) {
    return (
      <div className="flex items-center justify-center h-[350px] text-muted-foreground">No budget data available</div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="rounded-md border border-purple-200 dark:border-purple-800">
        <div className="grid grid-cols-5 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
          <div>Category</div>
          <div>Budget</div>
          <div>Actual</div>
          <div>Variance</div>
          <div>% Used</div>
        </div>
        <div className="divide-y divide-purple-200 dark:divide-purple-800">
          {budgetData.map((item, index) => (
            <div key={index} className="grid grid-cols-5 px-4 py-3">
              <div className="font-medium">{item.name}</div>
              <div>{formatCurrency(item.budget)}</div>
              <div>{formatCurrency(item.actual)}</div>
              <div className={item.variance >= 0 ? "text-green-600" : "text-red-600"}>
                {item.variance >= 0 ? "+" : ""}
                {formatCurrency(item.variance)}
              </div>
              <div className="flex items-center gap-2">
                <Progress
                  value={item.percentage}
                  className="h-2 w-24 bg-purple-100"
                  indicatorClassName={
                    item.percentage > 100 ? "bg-red-500" : item.percentage > 80 ? "bg-amber-500" : "bg-purple-600"
                  }
                />
                <span className="text-xs">{item.percentage.toFixed(0)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
