"use client"

import { useState } from "react"
import { CalendarIcon } from "lucide-react"
import { format, subMonths } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { ExpenseByCategory } from "@/components/expense-by-category"
import { MonthlyComparison } from "@/components/monthly-comparison"
import { BudgetVsActual } from "@/components/budget-vs-actual"
import { IncomeVsExpense } from "@/components/income-vs-expense"

export default function ReportsPage() {
  const [dateRange, setDateRange] = useState<{
    from: Date
    to: Date
  }>({
    from: subMonths(new Date(), 1),
    to: new Date(),
  })

  const [reportType, setReportType] = useState("expense-category")

  return (
    <DashboardShell>
      <DashboardHeader heading="Reports" text="Analyze your financial data">
        <div className="flex items-center space-x-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                id="date"
                variant={"outline"}
                className={cn("w-[300px] justify-start text-left font-normal", !dateRange && "text-muted-foreground")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateRange?.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                    </>
                  ) : (
                    format(dateRange.from, "LLL dd, y")
                  )
                ) : (
                  <span>Pick a date</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={dateRange?.from}
                selected={dateRange}
                onSelect={(range) => range && setDateRange(range)}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>
          <Select value={reportType} onValueChange={setReportType}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select report type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="expense-category">Expenses by Category</SelectItem>
              <SelectItem value="monthly">Monthly Comparison</SelectItem>
              <SelectItem value="budget-actual">Budget vs. Actual</SelectItem>
              <SelectItem value="income-expense">Income vs. Expense</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </DashboardHeader>

      <Tabs defaultValue="charts" className="space-y-4">
        <TabsList className="bg-purple-100 dark:bg-purple-900/50">
          <TabsTrigger value="charts" className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800">
            Charts
          </TabsTrigger>
          <TabsTrigger value="tables" className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800">
            Tables
          </TabsTrigger>
        </TabsList>
        <TabsContent value="charts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-purple-700 dark:text-purple-300">
                {reportType === "expense-category" && "Expenses by Category"}
                {reportType === "monthly" && "Monthly Comparison"}
                {reportType === "budget-actual" && "Budget vs. Actual Spending"}
                {reportType === "income-expense" && "Income vs. Expenses"}
              </CardTitle>
              <CardDescription>
                {reportType === "expense-category" && "Breakdown of your expenses by category"}
                {reportType === "monthly" && "Compare your spending month by month"}
                {reportType === "budget-actual" && "Compare your budgeted amounts with actual spending"}
                {reportType === "income-expense" && "Compare your income and expenses over time"}
              </CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              {reportType === "expense-category" && <ExpenseByCategory />}
              {reportType === "monthly" && <MonthlyComparison />}
              {reportType === "budget-actual" && <BudgetVsActual />}
              {reportType === "income-expense" && <IncomeVsExpense />}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="tables" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Report Data</CardTitle>
              <CardDescription>Tabular view of your financial data</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border border-purple-200 dark:border-purple-800">
                <div className="grid grid-cols-4 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
                  <div>Category</div>
                  <div>Amount</div>
                  <div>% of Total</div>
                  <div>Change from Previous</div>
                </div>
                <div className="divide-y divide-purple-200 dark:divide-purple-800">
                  <div className="grid grid-cols-4 px-4 py-3">
                    <div>Groceries</div>
                    <div>$420.50</div>
                    <div>24%</div>
                    <div className="text-green-500">-5%</div>
                  </div>
                  <div className="grid grid-cols-4 px-4 py-3">
                    <div>Rent</div>
                    <div>$1,200.00</div>
                    <div>45%</div>
                    <div className="text-muted-foreground">0%</div>
                  </div>
                  <div className="grid grid-cols-4 px-4 py-3">
                    <div>Utilities</div>
                    <div>$185.75</div>
                    <div>10%</div>
                    <div className="text-red-500">+8%</div>
                  </div>
                  <div className="grid grid-cols-4 px-4 py-3">
                    <div>Entertainment</div>
                    <div>$250.00</div>
                    <div>14%</div>
                    <div className="text-red-500">+12%</div>
                  </div>
                  <div className="grid grid-cols-4 px-4 py-3">
                    <div>Transportation</div>
                    <div>$120.25</div>
                    <div>7%</div>
                    <div className="text-green-500">-3%</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}
