"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ArrowLeft, Edit, Trash } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { formatCurrency } from "@/lib/utils"
import { getBudgets, getTransactions, deleteBudget, type Budget, type Transaction } from "@/lib/local-storage"
import Link from "next/link"
import { TransactionList } from "@/components/transaction-list"

export default function BudgetDetailsPage() {
  const router = useRouter()
  const params = useParams()
  const { user } = useAuth()
  const { toast } = useToast()

  const [budget, setBudget] = useState<Budget | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    const budgetId = params.id as string
    const budgets = getBudgets()
    const budget = budgets.find((b) => b.id === budgetId && b.userId === user.id)

    if (budget) {
      setBudget(budget)

      // Get transactions for this budget
      const allTransactions = getTransactions()
      const budgetTransactions = allTransactions.filter((t) => t.budgetId === budgetId && t.userId === user.id)
      setTransactions(budgetTransactions)
    } else {
      toast({
        title: "Budget not found",
        description: "The budget you're looking for doesn't exist",
        variant: "destructive",
      })
      router.push("/dashboard/budgets")
    }

    setLoading(false)
  }, [user, params.id, router, toast])

  const handleDelete = () => {
    if (!budget) return

    try {
      deleteBudget(budget.id)
      toast({
        title: "Budget deleted",
        description: "The budget has been deleted successfully",
      })
      router.push("/dashboard/budgets")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete budget. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return <div className="flex justify-center items-center h-[60vh]">Loading...</div>
  }

  if (!budget) {
    return <div className="text-center py-10">Budget not found</div>
  }

  const spent = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)
  const percentage = (spent / budget.amount) * 100

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="outline" onClick={() => router.back()} className="mr-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <h2 className="text-3xl font-bold tracking-tight text-purple-700 dark:text-purple-300">{budget.name}</h2>
        </div>
        <div className="flex space-x-2">
          <Link href={`/dashboard/budgets/${budget.id}/edit`}>
            <Button variant="outline">
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </Button>
          </Link>
          <Button variant="destructive" onClick={handleDelete}>
            <Trash className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      <Card className="border-purple-200 shadow-md dark:border-purple-800">
        <CardHeader>
          <CardTitle className="text-purple-700 dark:text-purple-300">Budget Overview</CardTitle>
          <CardDescription>{budget.description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Budget Amount</p>
              <p className="text-2xl font-bold">{formatCurrency(budget.amount)}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Spent Amount</p>
              <p className="text-2xl font-bold">{formatCurrency(spent)}</p>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Progress</span>
              <span
                className={`text-sm font-medium ${percentage > 100 ? "text-red-500" : percentage > 80 ? "text-amber-500" : "text-purple-600"}`}
              >
                {percentage.toFixed(0)}%
              </span>
            </div>
            <Progress
              value={percentage}
              className={`h-2 ${percentage > 100 ? "bg-red-200" : "bg-purple-100"}`}
              indicatorClassName={percentage > 100 ? "bg-red-500" : percentage > 80 ? "bg-amber-500" : "bg-purple-600"}
            />
            <p className="text-sm text-muted-foreground">
              {percentage > 100
                ? `Over budget by ${formatCurrency(spent - budget.amount)}`
                : `${budget.amount - spent > 0 ? `${formatCurrency(budget.amount - spent)} remaining` : "Budget depleted"}`}
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Transactions</CardTitle>
          <CardDescription>All transactions for this budget</CardDescription>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className="text-center py-6">
              <p className="text-muted-foreground mb-4">No transactions found for this budget.</p>
              <Link href="/dashboard/transactions/new">
                <Button>Add Transaction</Button>
              </Link>
            </div>
          ) : (
            <TransactionList transactions={transactions} />
          )}
        </CardContent>
      </Card>
    </div>
  )
}
