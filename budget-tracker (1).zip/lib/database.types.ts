export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          full_name: string
          phone_number: string
          created_at: string
        }
        Insert: {
          id: string
          full_name: string
          phone_number: string
          created_at?: string
        }
        Update: {
          id?: string
          full_name?: string
          phone_number?: string
          created_at?: string
        }
      }
      budgets: {
        Row: {
          id: string
          user_id: string
          name: string
          amount: number
          description: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          amount: number
          description?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          amount?: number
          description?: string | null
          created_at?: string
        }
      }
      transactions: {
        Row: {
          id: string
          user_id: string
          date: string
          description: string
          amount: number
          type: string
          category: string
          budget_id: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          date: string
          description: string
          amount: number
          type: string
          category: string
          budget_id?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          date?: string
          description?: string
          amount?: number
          type?: string
          category?: string
          budget_id?: string | null
          created_at?: string
        }
      }
      investments: {
        Row: {
          id: string
          user_id: string
          name: string
          type: string
          initial_investment: number
          current_value: number
          notes: string | null
          date_added: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          type: string
          initial_investment: number
          current_value: number
          notes?: string | null
          date_added: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          type?: string
          initial_investment?: number
          current_value?: number
          notes?: string | null
          date_added?: string
          created_at?: string
        }
      }
    }
  }
}
