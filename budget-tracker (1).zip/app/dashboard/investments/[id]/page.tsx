"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ArrowLeft, Edit, Plus, Trash, TrendingUp } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { formatCurrency } from "@/lib/utils"
import {
  getInvestments,
  deleteInvestment,
  addInvestmentContribution,
  deleteInvestmentContribution,
  updateInvestment,
  type Investment,
} from "@/lib/local-storage"
import Link from "next/link"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export default function InvestmentDetailsPage() {
  const router = useRouter()
  const params = useParams()
  const { user } = useAuth()
  const { toast } = useToast()

  const [investment, setInvestment] = useState<Investment | null>(null)
  const [loading, setLoading] = useState(true)
  const [contributionForm, setContributionForm] = useState({
    amount: "",
    notes: "",
  })
  const [isContributionDialogOpen, setIsContributionDialogOpen] = useState(false)
  const [isEditTargetDialogOpen, setIsEditTargetDialogOpen] = useState(false)
  const [targetForm, setTargetForm] = useState({
    targetAmount: "",
  })

  useEffect(() => {
    if (!user) return

    const fetchInvestment = () => {
      const investmentId = params.id as string
      const investments = getInvestments()
      const investment = investments.find((i) => i.id === investmentId && i.userId === user.id)

      if (investment) {
        setInvestment(investment)
        setTargetForm({
          targetAmount: investment.targetAmount.toString(),
        })
      } else {
        toast({
          title: "Investment not found",
          description: "The investment you're looking for doesn't exist",
          variant: "destructive",
        })
        router.push("/dashboard/investments")
      }

      setLoading(false)
    }

    fetchInvestment()
  }, [user, params.id, router, toast])

  const handleDelete = () => {
    if (!investment) return

    try {
      deleteInvestment(investment.id)
      toast({
        title: "Investment deleted",
        description: "The investment has been deleted successfully",
      })
      router.push("/dashboard/investments")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete investment. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleContributionChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setContributionForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleTargetChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setTargetForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleAddContribution = () => {
    if (!investment || !user) return

    try {
      const amount = Number.parseFloat(contributionForm.amount)

      if (isNaN(amount) || amount <= 0) {
        throw new Error("Amount must be a positive number")
      }

      const updatedInvestment = addInvestmentContribution(investment.id, {
        date: new Date().toISOString(),
        amount: amount,
        notes: contributionForm.notes || null,
      })

      if (updatedInvestment) {
        setInvestment(updatedInvestment)
        setContributionForm({ amount: "", notes: "" })
        setIsContributionDialogOpen(false)

        toast({
          title: "Contribution added",
          description: "Your contribution has been added successfully",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add contribution. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateTarget = () => {
    if (!investment) return

    try {
      const targetAmount = Number.parseFloat(targetForm.targetAmount)

      if (isNaN(targetAmount) || targetAmount <= 0) {
        throw new Error("Target amount must be a positive number")
      }

      const updatedInvestment = updateInvestment(investment.id, {
        targetAmount: targetAmount,
      })

      if (updatedInvestment) {
        setInvestment(updatedInvestment)
        setIsEditTargetDialogOpen(false)

        toast({
          title: "Target updated",
          description: "Your investment target has been updated successfully",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update target. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteContribution = (contributionId: string) => {
    if (!investment) return

    try {
      const updatedInvestment = deleteInvestmentContribution(investment.id, contributionId)

      if (updatedInvestment) {
        setInvestment(updatedInvestment)

        toast({
          title: "Contribution deleted",
          description: "The contribution has been deleted successfully",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete contribution. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return <div className="flex justify-center items-center h-[60vh]">Loading...</div>
  }

  if (!investment) {
    return <div className="text-center py-10">Investment not found</div>
  }

  const progressPercentage = (investment.currentValue / investment.targetAmount) * 100
  const remainingAmount = investment.targetAmount - investment.currentValue

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="outline" onClick={() => router.back()} className="mr-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <h2 className="text-3xl font-bold tracking-tight text-purple-700 dark:text-purple-300">{investment.name}</h2>
        </div>
        <div className="flex space-x-2">
          <Link href={`/dashboard/investments/${investment.id}/edit`}>
            <Button variant="outline">
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </Button>
          </Link>
          <Button variant="destructive" onClick={handleDelete}>
            <Trash className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-purple-200 shadow-md dark:border-purple-800">
          <CardHeader>
            <CardTitle className="text-purple-700 dark:text-purple-300">Investment Overview</CardTitle>
            <CardDescription>
              {investment.type} • {investment.notes}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Current Value</p>
                <p className="text-2xl font-bold">{formatCurrency(investment.currentValue)}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Initial Investment</p>
                <p className="text-2xl font-bold">{formatCurrency(investment.initialInvestment)}</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Target Progress</span>
                <div className="flex items-center">
                  <span className="text-sm font-medium mr-2">{progressPercentage.toFixed(0)}%</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-xs"
                    onClick={() => setIsEditTargetDialogOpen(true)}
                  >
                    Edit Target
                  </Button>
                </div>
              </div>
              <Progress value={progressPercentage} className="h-2 bg-purple-100" />
              <p className="text-sm text-muted-foreground">
                {formatCurrency(remainingAmount)} remaining to reach your target of{" "}
                {formatCurrency(investment.targetAmount)}
              </p>
            </div>

            <div className="pt-2">
              <div className="flex items-center space-x-2 text-sm">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <span className="text-green-600">
                  {(
                    ((investment.currentValue - investment.initialInvestment) / investment.initialInvestment) *
                    100
                  ).toFixed(2)}
                  % return
                </span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Dialog open={isContributionDialogOpen} onOpenChange={setIsContributionDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Contribution
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Contribution</DialogTitle>
                  <DialogDescription>Add a new contribution to your {investment.name} investment.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5">GHS</span>
                      <Input
                        id="amount"
                        name="amount"
                        type="number"
                        placeholder="0.00"
                        className="pl-12"
                        value={contributionForm.amount}
                        onChange={handleContributionChange}
                        min="0"
                        step="0.01"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      name="notes"
                      placeholder="Add any notes about this contribution"
                      value={contributionForm.notes}
                      onChange={handleContributionChange}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsContributionDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddContribution}>Add Contribution</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={isEditTargetDialogOpen} onOpenChange={setIsEditTargetDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Edit Target Amount</DialogTitle>
                  <DialogDescription>Update the target amount for your {investment.name} investment.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="targetAmount">Target Amount</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5">GHS</span>
                      <Input
                        id="targetAmount"
                        name="targetAmount"
                        type="number"
                        placeholder="0.00"
                        className="pl-12"
                        value={targetForm.targetAmount}
                        onChange={handleTargetChange}
                        min="0"
                        step="0.01"
                        required
                      />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsEditTargetDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleUpdateTarget}>Update Target</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardFooter>
        </Card>

        <Card className="border-purple-200 shadow-md dark:border-purple-800">
          <CardHeader>
            <CardTitle className="text-purple-700 dark:text-purple-300">Contribution History</CardTitle>
            <CardDescription>Track all contributions to this investment</CardDescription>
          </CardHeader>
          <CardContent>
            {investment.contributions.length === 0 ? (
              <div className="text-center py-6">
                <p className="text-muted-foreground mb-4">No contributions found for this investment.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {investment.contributions.map((contribution) => (
                  <div
                    key={contribution.id}
                    className="flex items-center justify-between p-3 border rounded-lg border-purple-200 dark:border-purple-800"
                  >
                    <div>
                      <p className="font-medium">{formatCurrency(contribution.amount)}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(contribution.date), "MMM d, yyyy")}
                      </p>
                      {contribution.notes && <p className="text-xs text-muted-foreground mt-1">{contribution.notes}</p>}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteContribution(contribution.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
