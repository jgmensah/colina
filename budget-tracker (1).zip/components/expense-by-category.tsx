"use client"

import type React from "react"

import { formatCurrency } from "@/lib/utils"
import type { Transaction } from "@/lib/local-storage"
import { Progress } from "@/components/ui/progress"

interface ExpenseByCategoryProps {
  transactions: Transaction[]
}

export function ExpenseByCategory({ transactions }: ExpenseByCategoryProps) {
  // Process data for the display
  const expenses = transactions.filter((t) => t.type === "expense")
  const totalExpenses = expenses.reduce((sum, t) => sum + t.amount, 0)

  // Group by category
  const categoryMap = new Map()
  expenses.forEach((expense) => {
    const category = expense.category
    if (categoryMap.has(category)) {
      categoryMap.set(category, categoryMap.get(category) + expense.amount)
    } else {
      categoryMap.set(category, expense.amount)
    }
  })

  const categoryData = Array.from(categoryMap.entries())
    .map(([name, value]) => ({
      name,
      value: value as number,
      percentage: totalExpenses > 0 ? ((value as number) / totalExpenses) * 100 : 0,
    }))
    .sort((a, b) => b.value - a.value)

  if (categoryData.length === 0) {
    return (
      <div className="flex items-center justify-center h-[350px] text-muted-foreground">
        No expense data available for the selected period
      </div>
    )
  }

  // Generate a color for each category
  const COLORS = ["#8b5cf6", "#a78bfa", "#c4b5fd", "#ddd6fe", "#7c3aed", "#6d28d9", "#5b21b6", "#4c1d95"]

  return (
    <div className="space-y-6">
      <div className="rounded-md border border-purple-200 dark:border-purple-800">
        <div className="grid grid-cols-4 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
          <div>Category</div>
          <div>Amount</div>
          <div>Percentage</div>
          <div>Distribution</div>
        </div>
        <div className="divide-y divide-purple-200 dark:divide-purple-800">
          {categoryData.map((category, index) => (
            <div key={index} className="grid grid-cols-4 px-4 py-3">
              <div className="font-medium">{category.name}</div>
              <div>{formatCurrency(category.value)}</div>
              <div>{category.percentage.toFixed(1)}%</div>
              <div className="flex items-center gap-2">
                <Progress
                  value={category.percentage}
                  className="h-2 w-24 bg-purple-100"
                  indicatorClassName="bg-purple-600"
                  style={
                    {
                      "--tw-bg-opacity": 1,
                      backgroundColor: COLORS[index % COLORS.length],
                    } as React.CSSProperties
                  }
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
        <h3 className="font-medium mb-2">Total Expenses</h3>
        <p className="text-lg font-medium">{formatCurrency(totalExpenses)}</p>
        <p className="text-sm text-muted-foreground mt-1">Across {categoryData.length} categories</p>
      </div>
    </div>
  )
}
