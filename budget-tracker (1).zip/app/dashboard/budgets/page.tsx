"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Edit, Plus, Trash } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useAuth } from "@/components/auth-provider"
import { formatCurrency } from "@/lib/utils"
import { getBudgets, getTransactions, deleteBudget, type Budget, type Transaction } from "@/lib/local-storage"
import { useToast } from "@/components/ui/use-toast"

export default function BudgetsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    const fetchData = () => {
      setLoading(true)
      const budgetData = getBudgets().filter((b) => b.userId === user.id)
      const transactionData = getTransactions().filter((t) => t.userId === user.id)

      setBudgets(budgetData)
      setTransactions(transactionData)
      setLoading(false)
    }

    fetchData()
  }, [user])

  const handleDelete = (id: string) => {
    try {
      deleteBudget(id)
      setBudgets(budgets.filter((budget) => budget.id !== id))
      toast({
        title: "Budget deleted",
        description: "The budget has been deleted successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete budget. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return <div className="flex justify-center items-center h-[60vh]">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold tracking-tight text-purple-700 dark:text-purple-300">Budgets</h2>
        <Link href="/dashboard/budgets/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Budget
          </Button>
        </Link>
      </div>

      {budgets.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <p className="text-muted-foreground mb-4">You haven't created any budgets yet.</p>
            <Link href="/dashboard/budgets/new">
              <Button>Create Your First Budget</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {budgets.map((budget) => {
            const spent = transactions
              .filter((t) => t.budgetId === budget.id && t.type === "expense")
              .reduce((sum, t) => sum + t.amount, 0)
            const percentage = (spent / budget.amount) * 100

            return (
              <Card key={budget.id} className="border-purple-200 shadow-md dark:border-purple-800">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-purple-700 dark:text-purple-300">{budget.name}</CardTitle>
                    <div className="flex space-x-2">
                      <Link href={`/dashboard/budgets/${budget.id}/edit`}>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-purple-600 hover:bg-purple-100 dark:text-purple-400 dark:hover:bg-purple-900/50"
                        >
                          <Edit className="h-4 w-4" />
                          <span className="sr-only">Edit</span>
                        </Button>
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(budget.id)}
                        className="text-purple-600 hover:bg-purple-100 dark:text-purple-400 dark:hover:bg-purple-900/50"
                      >
                        <Trash className="h-4 w-4" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </div>
                  </div>
                  <CardDescription>{budget.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium">
                      {formatCurrency(spent)} / {formatCurrency(budget.amount)}
                    </span>
                    <span
                      className={`text-sm font-medium ${percentage > 100 ? "text-red-500" : percentage > 80 ? "text-amber-500" : "text-purple-600"}`}
                    >
                      {percentage.toFixed(0)}%
                    </span>
                  </div>
                  <Progress
                    value={percentage}
                    className={`h-2 ${percentage > 100 ? "bg-red-200" : "bg-purple-100"}`}
                    indicatorClassName={
                      percentage > 100 ? "bg-red-500" : percentage > 80 ? "bg-amber-500" : "bg-purple-600"
                    }
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    {percentage > 100
                      ? `Over budget by ${formatCurrency(spent - budget.amount)}`
                      : `${budget.amount - spent > 0 ? `${formatCurrency(budget.amount - spent)} remaining` : "Budget depleted"}`}
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href={`/dashboard/budgets/${budget.id}`} className="w-full">
                    <Button
                      variant="outline"
                      className="w-full border-purple-300 text-purple-700 hover:bg-purple-100 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-900/50"
                    >
                      View Details
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
