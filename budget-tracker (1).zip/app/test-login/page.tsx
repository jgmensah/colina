"use client"

import { useState } from "react"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import Link from "next/link"

export default function TestLoginPage() {
  const { mockSignIn } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async (userId: string, userName: string) => {
    setIsLoading(true)
    try {
      await mockSignIn(userId)
      toast({
        title: "Logged in successfully",
        description: `You are now signed in as ${userName}`,
      })
    } catch (error) {
      toast({
        title: "Login failed",
        description: "There was an error logging in. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-gradient-to-r from-purple-600 to-purple-800 text-white dark:from-purple-900 dark:to-purple-950">
        <div className="container flex h-16 items-center px-4 sm:px-6">
          <Link href="/" className="text-lg font-semibold">
            Colina
          </Link>
        </div>
      </header>
      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-purple-700 dark:text-purple-300">Test Login</CardTitle>
            <CardDescription className="text-center">
              Select a sample user to test the application without authentication
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Button
                className="w-full"
                onClick={() => handleLogin("11111111-1111-1111-1111-111111111111", "Joshmen Carter")}
                disabled={isLoading}
              >
                Login as Joshmen Carter
              </Button>
              <p className="text-xs text-center text-muted-foreground">Phone: 0201234567</p>
            </div>

            <div className="space-y-2">
              <Button
                className="w-full"
                onClick={() => handleLogin("22222222-2222-2222-2222-222222222222", "Akosua Mensah")}
                disabled={isLoading}
              >
                Login as Akosua Mensah
              </Button>
              <p className="text-xs text-center text-muted-foreground">Phone: 0241234567</p>
            </div>

            <div className="space-y-2">
              <Button
                className="w-full"
                onClick={() => handleLogin("33333333-3333-3333-3333-333333333333", "Kwame Osei")}
                disabled={isLoading}
              >
                Login as Kwame Osei
              </Button>
              <p className="text-xs text-center text-muted-foreground">Phone: 0231234567</p>
            </div>

            <div className="mt-6 pt-6 border-t border-purple-200 dark:border-purple-800">
              <p className="text-sm text-center text-muted-foreground">
                This is a test login page for development purposes only.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
