"use client"

import { useState, useEffect } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ChartDebugPage() {
  // Simple static data that should definitely render
  const data = [
    { name: "Jan", value: 400 },
    { name: "Feb", value: 300 },
    { name: "Mar", value: 600 },
    { name: "Apr", value: 800 },
    { name: "May", value: 500 },
  ]

  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    console.log("Debug component mounted")
  }, [])

  if (!mounted) {
    return <div>Loading...</div>
  }

  return (
    <div className="p-8 space-y-8">
      <h1 className="text-3xl font-bold">Chart Debug Page</h1>
      <p className="text-lg">This page tests basic chart rendering with static data</p>

      <div className="grid grid-cols-1 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Basic Bar Chart Test</CardTitle>
          </CardHeader>
          <CardContent>
            <div style={{ width: "100%", height: "400px", border: "1px dashed red" }}>
              <p>Chart container - if you see only this text, the chart is not rendering</p>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>DOM Structure Test</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p>This section tests if basic DOM elements render correctly:</p>
              <div className="h-20 bg-purple-200 flex items-center justify-center">
                This is a purple box - if you see this, basic rendering works
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
