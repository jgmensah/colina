"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Plus, TrendingUp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useAuth } from "@/components/auth-provider"
import { formatCurrency } from "@/lib/utils"
import { getInvestments, type Investment } from "@/lib/local-storage"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { InvestmentPortfolio } from "@/components/investment-portfolio"
import { InvestmentPerformance } from "@/components/investment-performance"

export default function InvestmentsPage() {
  const { user } = useAuth()
  const [investments, setInvestments] = useState<Investment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    const fetchInvestments = () => {
      setLoading(true)
      const investmentData = getInvestments().filter((i) => i.userId === user.id)
      setInvestments(investmentData)
      setLoading(false)
    }

    fetchInvestments()
  }, [user])

  const totalInvestmentValue = investments.reduce((sum, inv) => sum + inv.currentValue, 0)
  const totalInvestmentCost = investments.reduce((sum, inv) => sum + inv.initialInvestment, 0)
  const totalTargetAmount = investments.reduce((sum, inv) => sum + inv.targetAmount, 0)
  const investmentGain = totalInvestmentValue - totalInvestmentCost
  const investmentGainPercentage = totalInvestmentCost > 0 ? (investmentGain / totalInvestmentCost) * 100 : 0
  const overallProgressPercentage = totalTargetAmount > 0 ? (totalInvestmentValue / totalTargetAmount) * 100 : 0

  if (loading) {
    return <div className="flex justify-center items-center h-[60vh]">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold tracking-tight text-purple-700 dark:text-purple-300">Investments</h2>
        <Link href="/dashboard/investments/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add Investment
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-purple-200 shadow-md dark:border-purple-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Portfolio Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalInvestmentValue)}</div>
            <p className="text-xs text-muted-foreground">{investments.length} investment assets</p>
          </CardContent>
        </Card>
        <Card className="border-purple-200 shadow-md dark:border-purple-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Gain/Loss</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${investmentGain >= 0 ? "text-green-600" : "text-red-600"}`}>
              {investmentGain >= 0 ? "+" : ""}
              {formatCurrency(investmentGain)}
            </div>
            <p className={`text-xs ${investmentGain >= 0 ? "text-green-600" : "text-red-600"}`}>
              {investmentGainPercentage >= 0 ? "+" : ""}
              {investmentGainPercentage.toFixed(2)}% overall return
            </p>
          </CardContent>
        </Card>
        <Card className="border-purple-200 shadow-md dark:border-purple-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Target Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">
                  {formatCurrency(totalInvestmentValue)} of {formatCurrency(totalTargetAmount)}
                </span>
                <span className="text-sm font-medium">{overallProgressPercentage.toFixed(0)}%</span>
              </div>
              <Progress value={overallProgressPercentage} className="h-2 bg-purple-100" />
              <p className="text-xs text-muted-foreground">
                {formatCurrency(totalTargetAmount - totalInvestmentValue)} remaining to reach your targets
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="investments" className="space-y-4">
        <TabsList className="bg-purple-100 dark:bg-purple-900/50">
          <TabsTrigger
            value="investments"
            className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800"
          >
            Investments
          </TabsTrigger>
          <TabsTrigger
            value="portfolio"
            className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800"
          >
            Portfolio
          </TabsTrigger>
          <TabsTrigger
            value="performance"
            className="data-[state=active]:bg-white dark:data-[state=active]:bg-purple-800"
          >
            Performance
          </TabsTrigger>
        </TabsList>

        <TabsContent value="investments" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {investments.length === 0 ? (
              <Card className="col-span-full">
                <CardContent className="flex flex-col items-center justify-center py-10">
                  <p className="text-muted-foreground mb-4">You haven't added any investments yet.</p>
                  <Link href="/dashboard/investments/new">
                    <Button>Add Your First Investment</Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              investments.map((investment) => {
                const gain = investment.currentValue - investment.initialInvestment
                const gainPercentage = (gain / investment.initialInvestment) * 100
                const progressPercentage = (investment.currentValue / investment.targetAmount) * 100

                return (
                  <Card key={investment.id} className="border-purple-200 shadow-md dark:border-purple-800">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-purple-700 dark:text-purple-300">{investment.name}</CardTitle>
                        <div className="flex items-center text-sm">
                          <TrendingUp className="mr-1 h-4 w-4 text-green-600" />
                          <span className={gainPercentage >= 0 ? "text-green-600" : "text-red-600"}>
                            {gainPercentage >= 0 ? "+" : ""}
                            {gainPercentage.toFixed(2)}%
                          </span>
                        </div>
                      </div>
                      <CardDescription>{investment.type}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-xs text-muted-foreground">Current Value</p>
                          <p className="font-medium">{formatCurrency(investment.currentValue)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Target</p>
                          <p className="font-medium">{formatCurrency(investment.targetAmount)}</p>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span>Progress</span>
                          <span>{progressPercentage.toFixed(0)}%</span>
                        </div>
                        <Progress value={progressPercentage} className="h-1.5 bg-purple-100" />
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Link href={`/dashboard/investments/${investment.id}`} className="w-full">
                        <Button
                          variant="outline"
                          className="w-full border-purple-300 text-purple-700 hover:bg-purple-100 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-900/50"
                        >
                          View Details
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                )
              })
            )}
          </div>
        </TabsContent>

        <TabsContent value="portfolio" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Investment Portfolio</CardTitle>
              <CardDescription>Your investment assets and their current values</CardDescription>
            </CardHeader>
            <CardContent>
              {investments.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-muted-foreground mb-4">You haven't added any investments yet.</p>
                  <Link href="/dashboard/investments/new">
                    <Button>Add Your First Investment</Button>
                  </Link>
                </div>
              ) : (
                <InvestmentPortfolio investments={investments} />
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Investment Performance</CardTitle>
              <CardDescription>Track the performance of your investments over time</CardDescription>
            </CardHeader>
            <CardContent>
              {investments.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-muted-foreground mb-4">You haven't added any investments yet.</p>
                  <Link href="/dashboard/investments/new">
                    <Button>Add Your First Investment</Button>
                  </Link>
                </div>
              ) : (
                <InvestmentPerformance investments={investments} />
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
