"use client"

import type React from "react"

import { formatCurrency } from "@/lib/utils"
import type { Investment } from "@/lib/local-storage"
import { Progress } from "@/components/ui/progress"

interface InvestmentPortfolioProps {
  investments: Investment[]
}

export function InvestmentPortfolio({ investments }: InvestmentPortfolioProps) {
  // Group investments by type
  const typeMap = new Map()
  let totalValue = 0

  investments.forEach((investment) => {
    const type = investment.type
    totalValue += investment.currentValue

    if (typeMap.has(type)) {
      typeMap.set(type, typeMap.get(type) + investment.currentValue)
    } else {
      typeMap.set(type, investment.currentValue)
    }
  })

  const typeData = Array.from(typeMap.entries())
    .map(([name, value]) => ({
      name,
      value: value as number,
      percentage: totalValue > 0 ? ((value as number) / totalValue) * 100 : 0,
    }))
    .sort((a, b) => b.value - a.value)

  if (investments.length === 0) {
    return (
      <div className="flex items-center justify-center h-[300px] text-muted-foreground">
        No investment data available
      </div>
    )
  }

  // Generate a color for each type
  const COLORS = ["#8b5cf6", "#a78bfa", "#c4b5fd", "#ddd6fe", "#7c3aed", "#6d28d9", "#5b21b6", "#4c1d95"]

  return (
    <div className="space-y-6">
      <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
        <h3 className="font-medium mb-4">Portfolio Allocation</h3>
        <div className="space-y-3">
          {typeData.map((type, index) => (
            <div key={index}>
              <div className="flex justify-between mb-1">
                <span className="font-medium">{type.name}</span>
                <span>
                  {formatCurrency(type.value)} ({type.percentage.toFixed(1)}%)
                </span>
              </div>
              <Progress
                value={type.percentage}
                className="h-3 bg-purple-100"
                indicatorClassName="bg-purple-600"
                style={
                  {
                    "--tw-bg-opacity": 1,
                    backgroundColor: COLORS[index % COLORS.length],
                  } as React.CSSProperties
                }
              />
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-md border border-purple-200 dark:border-purple-800">
        <div className="grid grid-cols-5 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
          <div>Name</div>
          <div>Type</div>
          <div>Current Value</div>
          <div>Target</div>
          <div>Progress</div>
        </div>
        <div className="divide-y divide-purple-200 dark:divide-purple-800">
          {investments.map((investment) => {
            const progressPercentage =
              investment.targetAmount > 0 ? (investment.currentValue / investment.targetAmount) * 100 : 0

            return (
              <div key={investment.id} className="grid grid-cols-5 px-4 py-3">
                <div className="font-medium">{investment.name}</div>
                <div>{investment.type}</div>
                <div>{formatCurrency(investment.currentValue)}</div>
                <div>{formatCurrency(investment.targetAmount)}</div>
                <div className="flex items-center gap-2">
                  <Progress
                    value={progressPercentage}
                    className="h-2 w-24 bg-purple-100"
                    indicatorClassName="bg-purple-600"
                  />
                  <span className="text-xs">{progressPercentage.toFixed(0)}%</span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
