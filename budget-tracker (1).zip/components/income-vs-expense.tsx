"use client"

import { eachMonthOfInterval, endOfMonth, format, startOfMonth, subMonths } from "date-fns"
import { formatCurrency } from "@/lib/utils"
import type { Transaction } from "@/lib/local-storage"
import { Progress } from "@/components/ui/progress"

interface IncomeVsExpenseProps {
  transactions: Transaction[]
}

export function IncomeVsExpense({ transactions }: IncomeVsExpenseProps) {
  // Calculate total income and expenses
  const totalIncome = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
  const totalExpenses = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)
  const totalSavings = totalIncome - totalExpenses
  const savingsRate = totalIncome > 0 ? (totalSavings / totalIncome) * 100 : 0

  // Generate data for the last 6 months
  const today = new Date()
  const sixMonthsAgo = subMonths(today, 5)

  const months = eachMonthOfInterval({
    start: sixMonthsAgo,
    end: today,
  })

  const monthlyData = months
    .map((month) => {
      const monthStart = startOfMonth(month)
      const monthEnd = endOfMonth(month)
      const monthName = format(month, "MMM yyyy")

      const monthTransactions = transactions.filter((t) => {
        const date = new Date(t.date)
        return date >= monthStart && date <= monthEnd
      })

      const income = monthTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
      const expenses = monthTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)
      const savings = income - expenses
      const savingsRate = income > 0 ? (savings / income) * 100 : 0
      const expenseToIncomeRatio = income > 0 ? (expenses / income) * 100 : 0

      return {
        month: monthName,
        income,
        expenses,
        savings,
        savingsRate,
        expenseToIncomeRatio,
      }
    })
    .reverse() // Show most recent month first

  if (totalIncome === 0 && totalExpenses === 0) {
    return (
      <div className="flex items-center justify-center h-[350px] text-muted-foreground">
        No transaction data available for the selected period
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
          <h3 className="font-medium mb-4">Income vs Expense Breakdown</h3>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span>Income</span>
                <span>{formatCurrency(totalIncome)}</span>
              </div>
              <Progress value={100} className="h-3 bg-purple-100" indicatorClassName="bg-green-500" />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span>Expenses</span>
                <span>{formatCurrency(totalExpenses)}</span>
              </div>
              <Progress
                value={totalIncome > 0 ? (totalExpenses / totalIncome) * 100 : 0}
                className="h-3 bg-purple-100"
                indicatorClassName="bg-red-500"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span>Savings</span>
                <span className={totalSavings >= 0 ? "text-green-600" : "text-red-600"}>
                  {totalSavings >= 0 ? "+" : ""}
                  {formatCurrency(totalSavings)}
                </span>
              </div>
              <Progress
                value={savingsRate > 0 ? savingsRate : 0}
                className="h-3 bg-purple-100"
                indicatorClassName="bg-purple-600"
              />
              <p className="text-xs text-right mt-1">Savings Rate: {savingsRate.toFixed(1)}%</p>
            </div>
          </div>
        </div>

        <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
          <h3 className="font-medium mb-2">Distribution</h3>
          <div className="flex items-center justify-center h-40">
            <div className="w-40 h-40 rounded-full border-8 border-purple-600 relative flex items-center justify-center">
              <div
                className="absolute inset-0 rounded-full bg-red-500"
                style={{
                  clipPath: `inset(0 0 0 ${totalIncome > 0 ? 100 - (totalExpenses / totalIncome) * 100 : 0}%)`,
                }}
              ></div>
              <div className="z-10 text-center">
                <p className="text-lg font-bold">
                  {totalIncome > 0 ? ((totalExpenses / totalIncome) * 100).toFixed(0) : 0}%
                </p>
                <p className="text-xs">Expense Ratio</p>
              </div>
            </div>
          </div>
          <p className="text-center text-sm mt-2">
            {totalExpenses <= totalIncome
              ? `You're spending ${((totalExpenses / totalIncome) * 100).toFixed(0)}% of your income`
              : `You're spending ${((totalExpenses / totalIncome) * 100).toFixed(0)}% of your income (overspending)`}
          </p>
        </div>
      </div>

      <div className="rounded-md border border-purple-200 dark:border-purple-800">
        <div className="grid grid-cols-4 border-b border-purple-200 px-4 py-2 font-medium dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20">
          <div>Month</div>
          <div>Income</div>
          <div>Expenses</div>
          <div>Expense Ratio</div>
        </div>
        <div className="divide-y divide-purple-200 dark:divide-purple-800">
          {monthlyData.map((month, index) => (
            <div key={index} className="grid grid-cols-4 px-4 py-3">
              <div className="font-medium">{month.month}</div>
              <div>{formatCurrency(month.income)}</div>
              <div>{formatCurrency(month.expenses)}</div>
              <div className="flex items-center gap-2">
                <Progress
                  value={month.expenseToIncomeRatio}
                  max={150}
                  className="h-2 w-24 bg-purple-100"
                  indicatorClassName={
                    month.expenseToIncomeRatio > 100
                      ? "bg-red-500"
                      : month.expenseToIncomeRatio > 80
                        ? "bg-amber-500"
                        : "bg-green-500"
                  }
                />
                <span className="text-xs">{month.expenseToIncomeRatio.toFixed(0)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
