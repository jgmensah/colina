"use client"

import { useState } from "react"
import { Moon, Sun, Laptop, Download } from "lucide-react"
import { useTheme } from "next-themes"
import { jsPDF } from "jspdf"
import "jspdf-autotable"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { getBudgets, getTransactions, getInvestments, clearAllData } from "@/lib/local-storage"

export default function SettingsPage() {
  const { theme, setTheme } = useTheme()
  const { toast } = useToast()
  const { user } = useAuth()

  const [notifications, setNotifications] = useState(true)
  const [currency, setCurrency] = useState("GHS")
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = () => {
    setIsSaving(true)

    // Simulate saving settings
    setTimeout(() => {
      toast({
        title: "Settings saved",
        description: "Your settings have been saved successfully",
      })
      setIsSaving(false)
    }, 1000)
  }

  const exportToPDF = () => {
    if (!user) {
      toast({
        title: "Authentication error",
        description: "You must be logged in to export data",
        variant: "destructive",
      })
      return
    }

    try {
      const budgets = getBudgets().filter((b) => b.userId === user.id)
      const transactions = getTransactions().filter((t) => t.userId === user.id)
      const investments = getInvestments().filter((i) => i.userId === user.id)

      // Calculate summary data
      const totalIncome = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

      const totalExpenses = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

      const totalInvestments = investments.reduce((sum, i) => sum + i.currentValue, 0)
      const totalInvestmentTargets = investments.reduce((sum, i) => sum + i.targetAmount, 0)
      const investmentProgress = totalInvestmentTargets > 0 ? (totalInvestments / totalInvestmentTargets) * 100 : 0

      const doc = new jsPDF()

      // Title
      doc.setFontSize(20)
      doc.setTextColor(128, 0, 128) // Purple color
      doc.text("Colina Financial Report", 105, 15, { align: "center" })

      // Subtitle
      doc.setFontSize(12)
      doc.setTextColor(0, 0, 0)
      doc.text(`Generated on: ${format(new Date(), "PPP")}`, 105, 25, { align: "center" })

      // Summary section
      doc.setFontSize(16)
      doc.text("Financial Summary", 14, 45)

      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: 50,
        head: [["Metric", "Value"]],
        body: [
          ["Total Income", `${currency} ${totalIncome.toFixed(2)}`],
          ["Total Expenses", `${currency} ${totalExpenses.toFixed(2)}`],
          ["Net Savings", `${currency} ${(totalIncome - totalExpenses).toFixed(2)}`],
          ["Total Investments", `${currency} ${totalInvestments.toFixed(2)}`],
          ["Investment Target Progress", `${investmentProgress.toFixed(1)}%`],
        ],
        theme: "grid",
        headStyles: { fillColor: [128, 0, 128] },
      })

      // Transactions
      const finalY1 = (doc as any).lastAutoTable.finalY + 10
      doc.setFontSize(16)
      doc.text("Recent Transactions", 14, finalY1)

      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: finalY1 + 5,
        head: [["Date", "Description", "Type", "Amount"]],
        body: transactions
          .slice(0, 10)
          .map((t) => [
            format(new Date(t.date), "yyyy-MM-dd"),
            t.description,
            t.type,
            `${currency} ${t.amount.toFixed(2)}`,
          ]),
        theme: "grid",
        headStyles: { fillColor: [128, 0, 128] },
      })

      // Add a new page for investments
      doc.addPage()

      // Investments
      doc.setFontSize(16)
      doc.text("Investments", 14, 15)

      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: 20,
        head: [["Name", "Type", "Current Value", "Target", "Progress"]],
        body: investments.map((i) => [
          i.name,
          i.type,
          `${currency} ${i.currentValue.toFixed(2)}`,
          `${currency} ${i.targetAmount.toFixed(2)}`,
          `${((i.currentValue / i.targetAmount) * 100).toFixed(1)}%`,
        ]),
        theme: "grid",
        headStyles: { fillColor: [128, 0, 128] },
      })

      // Add a new page for budgets
      doc.addPage()

      // Budgets
      doc.setFontSize(16)
      doc.text("Budgets", 14, 15)

      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: 20,
        head: [["Name", "Type", "Amount", "Description"]],
        body: budgets.map((b) => [b.name, b.type, `${currency} ${b.amount.toFixed(2)}`, b.description || ""]),
        theme: "grid",
        headStyles: { fillColor: [128, 0, 128] },
      })

      // Save the PDF
      doc.save("colina-financial-report.pdf")

      toast({
        title: "Export successful",
        description: "Your financial report has been exported to PDF",
      })
    } catch (error) {
      toast({
        title: "Export failed",
        description: "There was an error exporting your data",
        variant: "destructive",
      })
      console.error("Export error:", error)
    }
  }

  const handleClearData = () => {
    if (confirm("Are you sure you want to clear all your data? This action cannot be undone.")) {
      clearAllData()
      toast({
        title: "Data cleared",
        description: "All your data has been cleared successfully",
      })
      // Reload the page to reflect changes
      window.location.reload()
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold tracking-tight text-purple-700 dark:text-purple-300">Settings</h2>
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? "Saving..." : "Save Changes"}
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Customize how the app looks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>Theme</Label>
              <RadioGroup defaultValue={theme} onValueChange={setTheme} className="grid grid-cols-3 gap-4">
                <div>
                  <RadioGroupItem value="light" id="light" className="peer sr-only" />
                  <Label
                    htmlFor="light"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-purple-50 hover:text-purple-700 peer-data-[state=checked]:border-purple-600 [&:has([data-state=checked])]:border-purple-600 dark:hover:bg-purple-900/50 dark:hover:text-purple-300 dark:peer-data-[state=checked]:border-purple-500 dark:[&:has([data-state=checked])]:border-purple-500"
                  >
                    <Sun className="mb-2 h-6 w-6" />
                    Light
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="dark" id="dark" className="peer sr-only" />
                  <Label
                    htmlFor="dark"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-purple-50 hover:text-purple-700 peer-data-[state=checked]:border-purple-600 [&:has([data-state=checked])]:border-purple-600 dark:hover:bg-purple-900/50 dark:hover:text-purple-300 dark:peer-data-[state=checked]:border-purple-500 dark:[&:has([data-state=checked])]:border-purple-500"
                  >
                    <Moon className="mb-2 h-6 w-6" />
                    Dark
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="system" id="system" className="peer sr-only" />
                  <Label
                    htmlFor="system"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-purple-50 hover:text-purple-700 peer-data-[state=checked]:border-purple-600 [&:has([data-state=checked])]:border-purple-600 dark:hover:bg-purple-900/50 dark:hover:text-purple-300 dark:peer-data-[state=checked]:border-purple-500 dark:[&:has([data-state=checked])]:border-purple-500"
                  >
                    <Laptop className="mb-2 h-6 w-6" />
                    System
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Preferences</CardTitle>
            <CardDescription>Manage your app preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="notifications">Notifications</Label>
                <p className="text-sm text-muted-foreground">Receive notifications about your finances</p>
              </div>
              <Switch id="notifications" checked={notifications} onCheckedChange={setNotifications} />
            </div>

            <div className="space-y-2">
              <Label>Currency</Label>
              <RadioGroup defaultValue={currency} onValueChange={setCurrency} className="grid grid-cols-2 gap-4">
                <div>
                  <RadioGroupItem value="GHS" id="ghs" className="peer sr-only" />
                  <Label
                    htmlFor="ghs"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-purple-50 hover:text-purple-700 peer-data-[state=checked]:border-purple-600 [&:has([data-state=checked])]:border-purple-600 dark:hover:bg-purple-900/50 dark:hover:text-purple-300 dark:peer-data-[state=checked]:border-purple-500 dark:[&:has([data-state=checked])]:border-purple-500"
                  >
                    GHS (₵)
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="NGN" id="ngn" className="peer sr-only" />
                  <Label
                    htmlFor="ngn"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-purple-50 hover:text-purple-700 peer-data-[state=checked]:border-purple-600 [&:has([data-state=checked])]:border-purple-600 dark:hover:bg-purple-900/50 dark:hover:text-purple-300 dark:peer-data-[state=checked]:border-purple-500 dark:[&:has([data-state=checked])]:border-purple-500"
                  >
                    NGN (₦)
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="EUR" id="eur" className="peer sr-only" />
                  <Label
                    htmlFor="eur"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-purple-50 hover:text-purple-700 peer-data-[state=checked]:border-purple-600 [&:has([data-state=checked])]:border-purple-600 dark:hover:bg-purple-900/50 dark:hover:text-purple-300 dark:peer-data-[state=checked]:border-purple-500 dark:[&:has([data-state=checked])]:border-purple-500"
                  >
                    EUR (€)
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="GBP" id="gbp" className="peer sr-only" />
                  <Label
                    htmlFor="gbp"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-purple-50 hover:text-purple-700 peer-data-[state=checked]:border-purple-600 [&:has([data-state=checked])]:border-purple-600 dark:hover:bg-purple-900/50 dark:hover:text-purple-300 dark:peer-data-[state=checked]:border-purple-500 dark:[&:has([data-state=checked])]:border-purple-500"
                  >
                    GBP (£)
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="USD" id="usd" className="peer sr-only" />
                  <Label
                    htmlFor="usd"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-purple-50 hover:text-purple-700 peer-data-[state=checked]:border-purple-600 [&:has([data-state=checked])]:border-purple-600 dark:hover:bg-purple-900/50 dark:hover:text-purple-300 dark:peer-data-[state=checked]:border-purple-500 dark:[&:has([data-state=checked])]:border-purple-500"
                  >
                    USD ($)
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Data Management</CardTitle>
            <CardDescription>Manage your app data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              You can export your data or clear all data from the app. Exporting data will download a file with all your
              financial information.
            </p>
            <div className="grid grid-cols-1 gap-2">
              <Button variant="outline" onClick={exportToPDF} className="flex items-center">
                <Download className="mr-2 h-4 w-4" />
                Export to PDF
              </Button>
            </div>
            <div className="pt-2">
              <Button variant="destructive" onClick={handleClearData} className="w-full">
                Clear All Data
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>About</CardTitle>
            <CardDescription>Information about the app</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm">
              <span className="font-medium">Colina</span> - Financial Management App
            </p>
            <p className="text-sm">Version 1.0.0</p>
            <p className="text-sm text-muted-foreground">
              Colina is a comprehensive financial management application designed to help users take control of their
              finances.
            </p>
          </CardContent>
          <CardFooter>
            <p className="text-xs text-muted-foreground">© 2024 Colina. All rights reserved.</p>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
