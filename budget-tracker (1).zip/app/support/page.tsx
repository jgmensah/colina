import Link from "next/link"
import { ArrowLeft, Mail, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ModeToggle } from "@/components/mode-toggle"

export default function SupportPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-gradient-to-r from-purple-600 to-purple-800 text-white dark:from-purple-900 dark:to-purple-950">
        <div className="container flex h-16 items-center px-4 sm:px-6">
          <Link href="/" className="text-lg font-semibold">
            Colina
          </Link>
          <nav className="ml-auto flex gap-4 items-center">
            <Link href="/" className="text-sm font-medium hover:text-purple-200">
              Home
            </Link>
            <Link href="/dashboard" className="text-sm font-medium hover:text-purple-200">
              Dashboard
            </Link>
            <ModeToggle />
          </nav>
        </div>
      </header>

      <main className="flex-1 container py-12">
        <div className="flex items-center mb-8">
          <Link href="/">
            <Button variant="outline" className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-purple-700 dark:text-purple-300">Support</h1>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          <Card className="border-purple-200 shadow-md dark:border-purple-800">
            <CardHeader>
              <CardTitle className="text-purple-700 dark:text-purple-300">Contact Us</CardTitle>
              <CardDescription>Get in touch with our support team</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-start space-x-4">
                <Phone className="h-5 w-5 text-purple-600 mt-0.5" />
                <div>
                  <h3 className="font-medium">WhatsApp</h3>
                  <p className="text-muted-foreground">For quick assistance, reach out via WhatsApp</p>
                  <a
                    href="https://wa.me/233205036042"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-purple-600 hover:text-purple-800 dark:text-purple-400 dark:hover:text-purple-300 font-medium"
                  >
                    +233 20 503 6042
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <Mail className="h-5 w-5 text-purple-600 mt-0.5" />
                <div>
                  <h3 className="font-medium">Email</h3>
                  <p className="text-muted-foreground">Send us an email for detailed inquiries</p>
                  <a
                    href="mailto:support@colina.com"
                    className="text-purple-600 hover:text-purple-800 dark:text-purple-400 dark:hover:text-purple-300 font-medium"
                  >
                    support@colina.com
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-200 shadow-md dark:border-purple-800">
            <CardHeader>
              <CardTitle className="text-purple-700 dark:text-purple-300">Frequently Asked Questions</CardTitle>
              <CardDescription>Quick answers to common questions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-medium">Is my financial data secure?</h3>
                <p className="text-muted-foreground">
                  Yes, we use industry-standard encryption and security practices to protect your data. Your financial
                  information is stored securely and is not shared with third parties.
                </p>
              </div>

              <div>
                <h3 className="font-medium">Can I use Colina on multiple devices?</h3>
                <p className="text-muted-foreground">
                  Yes, Colina is a web-based application that can be accessed from any device with a web browser. You
                  can also install it as a Progressive Web App (PWA) on your mobile device for offline access.
                </p>
              </div>

              <div>
                <h3 className="font-medium">How do I reset my PIN?</h3>
                <p className="text-muted-foreground">
                  If you've forgotten your PIN, you can use the "Forgot PIN" option on the sign-in page. You'll receive
                  instructions to reset your PIN via your registered phone number.
                </p>
              </div>

              <div>
                <h3 className="font-medium">Is Colina free to use?</h3>
                <p className="text-muted-foreground">
                  Colina offers a free basic plan with essential features. We also offer premium plans with advanced
                  features for users who need more comprehensive financial management tools.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="border-t border-purple-200 py-6 md:py-0 bg-white dark:bg-purple-950 dark:border-purple-800">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-purple-600 dark:text-purple-300">© 2024 Colina. All rights reserved.</p>
          <div className="flex gap-4">
            <Link
              href="/about"
              className="text-sm text-purple-600 hover:text-purple-800 dark:text-purple-300 dark:hover:text-purple-100"
            >
              About
            </Link>
            <Link
              href="/support"
              className="text-sm text-purple-600 hover:text-purple-800 dark:text-purple-300 dark:hover:text-purple-100"
            >
              Support
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
