"use client"

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import { BudgetData, TransactionData } from "@/lib/data"

export function BudgetVsActual() {
  // Process data for the chart
  const chartData = BudgetData.map((budget) => {
    const spent = TransactionData.filter((t) => t.budgetId === budget.id && t.type === "expense").reduce(
      (sum, t) => sum + t.amount,
      0,
    )

    return {
      name: budget.name,
      budget: budget.amount,
      actual: spent,
      variance: budget.amount - spent,
    }
  })

  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip formatter={(value) => [`$${value}`, ""]} labelFormatter={(label) => `Category: ${label}`} />
        <Legend />
        <Bar dataKey="budget" fill="#8b5cf6" name="Budget" />
        <Bar dataKey="actual" fill="#c4b5fd" name="Actual" />
      </BarChart>
    </ResponsiveContainer>
  )
}
