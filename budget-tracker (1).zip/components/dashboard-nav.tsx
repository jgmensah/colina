"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { BarChart3, CreditCard, Home, LineChart, PiggyBank, Settings, HelpCircle, Info, User } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface NavItem {
  title: string
  href: string
  icon: React.ReactNode
}

export function DashboardNav() {
  const pathname = usePathname()

  const navItems: NavItem[] = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: <Home className="mr-2 h-4 w-4" />,
    },
    {
      title: "Budgets",
      href: "/dashboard/budgets",
      icon: <PiggyBank className="mr-2 h-4 w-4" />,
    },
    {
      title: "Transactions",
      href: "/dashboard/transactions",
      icon: <CreditCard className="mr-2 h-4 w-4" />,
    },
    {
      title: "Investments",
      href: "/dashboard/investments",
      icon: <LineChart className="mr-2 h-4 w-4" />,
    },
    {
      title: "Reports",
      href: "/dashboard/reports",
      icon: <BarChart3 className="mr-2 h-4 w-4" />,
    },
    {
      title: "Profile",
      href: "/dashboard/profile",
      icon: <User className="mr-2 h-4 w-4" />,
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: <Settings className="mr-2 h-4 w-4" />,
    },
    {
      title: "About",
      href: "/about",
      icon: <Info className="mr-2 h-4 w-4" />,
    },
    {
      title: "Support",
      href: "/support",
      icon: <HelpCircle className="mr-2 h-4 w-4" />,
    },
  ]

  return (
    <nav className="flex flex-col gap-2 p-4">
      {navItems.map((item) => (
        <Link key={item.href} href={item.href}>
          <Button
            variant="ghost"
            className={cn(
              "w-full justify-start",
              pathname === item.href
                ? "bg-purple-100 text-purple-700 hover:bg-purple-100 hover:text-purple-700 dark:bg-purple-900/50 dark:text-purple-300 dark:hover:bg-purple-900/50 dark:hover:text-purple-300"
                : "text-gray-600 hover:bg-purple-100 hover:text-purple-700 dark:text-gray-300 dark:hover:bg-purple-900/50 dark:hover:text-purple-300",
            )}
          >
            {item.icon}
            {item.title}
          </Button>
        </Link>
      ))}
    </nav>
  )
}
