"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowDownLeft, ArrowUpRight, Filter, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TransactionData } from "@/lib/data"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { TransactionList } from "@/components/transaction-list"

export default function TransactionsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")

  const filteredTransactions = TransactionData.filter((transaction) => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = filterType === "all" || transaction.type === filterType
    return matchesSearch && matchesType
  })

  return (
    <DashboardShell>
      <DashboardHeader heading="Transactions" text="View and manage your transactions">
        <Link href="/transactions/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add Transaction
          </Button>
        </Link>
      </DashboardHeader>
      <Card>
        <CardHeader>
          <CardTitle>All Transactions</CardTitle>
          <CardDescription>A list of all your transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-x-4 md:space-y-0">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search transactions..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Transactions</SelectItem>
                  <SelectItem value="income">Income Only</SelectItem>
                  <SelectItem value="expense">Expenses Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="mt-6 space-y-1">
            <div className="flex justify-between text-sm font-medium text-muted-foreground">
              <span>Summary</span>
              <span>Amount</span>
            </div>
            <div className="flex items-center justify-between rounded-md bg-purple-50 px-4 py-2 dark:bg-purple-900/20">
              <div className="flex items-center space-x-2">
                <ArrowUpRight className="h-4 w-4 text-purple-600" />
                <span>Total Income</span>
              </div>
              <span className="font-medium text-purple-600">
                +$
                {filteredTransactions
                  .filter((t) => t.type === "income")
                  .reduce((sum, t) => sum + t.amount, 0)
                  .toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between rounded-md bg-muted px-4 py-2">
              <div className="flex items-center space-x-2">
                <ArrowDownLeft className="h-4 w-4 text-red-500" />
                <span>Total Expenses</span>
              </div>
              <span className="font-medium text-red-500">
                -$
                {filteredTransactions
                  .filter((t) => t.type === "expense")
                  .reduce((sum, t) => sum + t.amount, 0)
                  .toFixed(2)}
              </span>
            </div>
          </div>

          <div className="mt-6">
            <TransactionList transactions={filteredTransactions} />
          </div>
        </CardContent>
      </Card>
    </DashboardShell>
  )
}
